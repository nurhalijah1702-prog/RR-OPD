import { useState } from "react";
import { RiskItem } from "../types";
import { Edit2, ShieldAlert, CheckCircle, Info, Calendar, User, Save, X } from "lucide-react";

interface RencanaTindakPengendalianFormProps {
  risks: RiskItem[];
  onUpdateRTP: (id: string, updatedRTP: Partial<RiskItem>) => void;
}

export function RencanaTindakPengendalianForm(props: RencanaTindakPengendalianFormProps) {
  const { risks, onUpdateRTP } = props;

  // Track which risk is currently being edited
  const [editingId, setEditingId] = useState<string | null>(null);

  // Local Form state for editing RTP
  const [rtpUraianAda, setRtpUraianAda] = useState("");
  const [rtpAlasanTidakEfektif, setRtpAlasanTidakEfektif] = useState("");
  const [rtpDibutuhkan, setRtpDibutuhkan] = useState("");
  const [rtpCelah, setRtpCelah] = useState("");
  const [rtpRencanaTindakan, setRtpRencanaTindakan] = useState("");
  const [rtpPenanggungJawab, setRtpPenanggungJawab] = useState("");
  const [rtpTargetWaktu, setRtpTargetWaktu] = useState("");

  const startEditing = (risk: RiskItem) => {
    setEditingId(risk.id);
    setRtpUraianAda(risk.rtpUraianAda || "");
    setRtpAlasanTidakEfektif(risk.rtpAlasanTidakEfektif || "");
    setRtpDibutuhkan(risk.rtpDibutuhkan || "");
    setRtpCelah(risk.rtpCelah || "");
    setRtpRencanaTindakan(risk.rtpRencanaTindakan || "");
    setRtpPenanggungJawab(risk.rtpPenanggungJawab || risk.pemilikRisiko);
    setRtpTargetWaktu(risk.rtpTargetWaktu || "");
  };

  const handleSave = (riskId: string) => {
    onUpdateRTP(riskId, {
      rtpUraianAda,
      rtpAlasanTidakEfektif,
      rtpDibutuhkan,
      rtpCelah,
      rtpRencanaTindakan,
      rtpPenanggungJawab,
      rtpTargetWaktu,
    });
    setEditingId(null);
  };

  const ALASAN_OPTIONS = [
    { key: "(1) Kebijakan dan Prosedur pengendalian sudah dilakukan, namun belum mampu menangani risiko yang teridentifikasi", label: "Kebijakan Ada Tapi Belum Efektif" },
    { key: "(2) Prosedur pengendalian belum/tidak dapat dilaksanakan", label: "Prosedur Belum Bisa Dilaksanakan" },
    { key: "(3) Kebijakan belum diikuti dengan prosedur baku yang jelas", label: "Kebijakan Tanpa Prosedur Baku" },
    { key: "(4) Kebijakan dan prosedur yang ada tidak sesuai dengan peraturan diatasnya", label: "Kebijakan Tidak Selaras Aturan Atas" }
  ];

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
      
      {/* Title */}
      <div className="pb-4 mb-6 border-b border-slate-100 dark:border-slate-800">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-amber-500" />
          Rencana Tindak Pengendalian (RTP) & Celah Kontrol
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Penilaian atas kelemahan sistem pengendalian intern yang sudah berjalan (celah kontrol) dan rancangan program perbaikan yang komprehensif.
        </p>
      </div>

      {/* Guide Card for Ineffectiveness */}
      <div className="mb-6 bg-slate-50 dark:bg-slate-800/45 p-4 border border-slate-200 dark:border-slate-800 rounded-lg text-xs">
        <div className="font-bold flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
          <Info className="w-4.5 h-4.5 text-amber-500" />
          <span>Pedoman Alasan Pengendalian Tidak Efektif (Lampiran SPIP):</span>
        </div>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2 mt-3 list-disc list-inside text-slate-600 dark:text-slate-400 font-medium">
          <li><strong>(1)</strong> Kebijakan ada, tapi belum mampu menangani risiko</li>
          <li><strong>(2)</strong> Prosedur ada, tapi tidak dapat dilaksanakan (kandand)</li>
          <li><strong>(3)</strong> Kebijakan belum diikuti prosedur baku (SOP)</li>
          <li><strong>(4)</strong> Regulasi lokal tidak sesuai peraturan kementerian/pusat</li>
        </ul>
      </div>

      {/* Risk RTP Cards/Table */}
      <div className="space-y-4">
        {risks.map((risk, index) => {
          const isEditing = editingId === risk.id;

          return (
            <div
              key={`rtp-card-${risk.id}`}
              className={`border rounded-xl transition-all p-5 ${
                isEditing
                  ? "border-amber-500 shadow-md bg-amber-50/5 dark:bg-slate-850/20"
                  : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 hover:shadow-xs"
              }`}
            >
              {/* Card Header */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 pb-3 border-b border-slate-100 dark:border-slate-800/60 mb-4">
                <div className="flex items-center gap-2">
                  <span className="flex items-center justify-center w-5 h-5 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded font-bold text-xs">
                    {index + 1}
                  </span>
                  <span className="font-mono font-bold text-amber-600 dark:text-amber-400 text-xs">
                    {risk.kodeRisiko}
                  </span>
                  <h3 className="font-bold text-sm text-slate-950 dark:text-slate-100">
                    {risk.uraianRisiko}
                  </h3>
                </div>
                
                {!isEditing && (
                  <button
                    onClick={() => startEditing(risk)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded text-xs font-bold cursor-pointer transition-colors"
                  >
                    <Edit2 className="w-3.5 h-3.5 text-amber-500" />
                    <span>Kelola RTP</span>
                  </button>
                )}
              </div>

              {/* View Mode */}
              {!isEditing ? (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-600 dark:text-slate-400">
                  {/* Left Column: Existing Controls */}
                  <div className="space-y-3 bg-slate-50/50 dark:bg-slate-800/20 p-3 rounded-lg border border-slate-100 dark:border-slate-800/60">
                    <div>
                      <span className="block font-bold text-slate-400 uppercase tracking-wider text-[9px] mb-1">Pengendalian yang Sudah Ada</span>
                      <p className="text-slate-800 dark:text-slate-300 font-medium italic">
                        {risk.rtpUraianAda || "Belum diidentifikasi / Kosong"}
                      </p>
                    </div>
                    {risk.rtpAlasanTidakEfektif && (
                      <div>
                        <span className="block font-bold text-slate-400 uppercase tracking-wider text-[9px] mb-0.5">Alasan Tidak Efektif</span>
                        <p className="text-rose-600 dark:text-rose-400 font-semibold text-[10px]">
                          {risk.rtpAlasanTidakEfektif}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Middle Column: Missing Controls & Gap */}
                  <div className="space-y-3 bg-slate-50/50 dark:bg-slate-800/20 p-3 rounded-lg border border-slate-100 dark:border-slate-800/60">
                    <div>
                      <span className="block font-bold text-slate-400 uppercase tracking-wider text-[9px] mb-1">Celah Pengendalian (Gap)</span>
                      <p className="text-slate-800 dark:text-slate-300 font-medium">
                        {risk.rtpCelah || "Belum diidentifikasi / Kosong"}
                      </p>
                    </div>
                    <div>
                      <span className="block font-bold text-slate-400 uppercase tracking-wider text-[9px] mb-1">Pengendalian Tambahan yg Dibutuhkan</span>
                      <p className="text-slate-800 dark:text-slate-300 font-medium">
                        {risk.rtpDibutuhkan || "Belum diidentifikasi / Kosong"}
                      </p>
                    </div>
                  </div>

                  {/* Right Column: Planned Action Roadmap (RTP) */}
                  <div className="space-y-3 bg-amber-500/5 dark:bg-amber-500/2 p-3 rounded-lg border border-amber-500/10">
                    <div>
                      <span className="block font-bold text-slate-400 uppercase tracking-wider text-[9px] mb-1">Rencana Tindak Pengendalian (RTP)</span>
                      <p className="text-slate-900 dark:text-slate-200 font-bold leading-relaxed">
                        {risk.rtpRencanaTindakan || "Belum disusun"}
                      </p>
                    </div>
                    
                    <div className="flex flex-wrap gap-x-4 gap-y-1.5 pt-2 border-t border-slate-100 dark:border-slate-800 text-[10px]">
                      <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>PJ: <strong className="text-slate-700 dark:text-slate-200">{risk.rtpPenanggungJawab || risk.pemilikRisiko}</strong></span>
                      </div>
                      <div className="flex items-center gap-1 text-slate-500 dark:text-slate-400">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>Target: <strong className="text-slate-700 dark:text-slate-200">{risk.rtpTargetWaktu || "-"}</strong></span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                /* Edit Mode */
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    
                    {/* Existing Controls */}
                    <div className="space-y-3">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Pengendalian yang Sudah Ada</label>
                        <textarea
                          value={rtpUraianAda}
                          onChange={(e) => setRtpUraianAda(e.target.value)}
                          rows={2}
                          placeholder="Sebutkan instrumen pengawasan, SOP, atau kebijakan yang sudah ada/terpasang..."
                          className="w-full text-xs bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 p-2 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Sebab Tidak Efektif (Kategori SPIP)</label>
                        <select
                          value={rtpAlasanTidakEfektif}
                          onChange={(e) => setRtpAlasanTidakEfektif(e.target.value)}
                          className="w-full text-xs bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 p-2 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none"
                        >
                          <option value="">-- Pilih Alasan Ketidakefektifan (Jika ada) --</option>
                          {ALASAN_OPTIONS.map((opt) => (
                            <option key={`opt-alasan-${opt.key}`} value={opt.key}>
                              {opt.key}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Gap Identification */}
                    <div className="space-y-3">
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Celah Pengendalian (Gap)</label>
                        <textarea
                          value={rtpCelah}
                          onChange={(e) => setRtpCelah(e.target.value)}
                          rows={2}
                          placeholder="Analisis celah kelemahan dalam sistem saat ini..."
                          className="w-full text-xs bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 p-2 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Pengendalian Tambahan yg Masih Dibutuhkan</label>
                        <textarea
                          value={rtpDibutuhkan}
                          onChange={(e) => setRtpDibutuhkan(e.target.value)}
                          rows={2}
                          placeholder="Ide/rekomendasi instrumen perbaikan baru yang ideal..."
                          className="w-full text-xs bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 p-2 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500"
                        />
                      </div>
                    </div>

                  </div>

                  {/* Rencana Tindak Pengendalian (RTP) - Formal Plan */}
                  <div className="bg-amber-500/5 dark:bg-slate-800/40 p-4 rounded-lg border border-amber-500/20 space-y-3">
                    <div>
                      <label className="block text-[10px] font-bold text-amber-800 dark:text-amber-400 uppercase mb-1">Format Rencana Tindak Pengendalian (RTP) Utama</label>
                      <textarea
                        value={rtpRencanaTindakan}
                        onChange={(e) => setRtpRencanaTindakan(e.target.value)}
                        rows={2}
                        placeholder="Uraikan aksi nyata, program, atau revisi peraturan yang akan dibuat dalam RTP..."
                        className="w-full text-xs bg-white dark:bg-slate-800 text-slate-850 dark:text-slate-100 p-2.5 border border-slate-300 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500 font-bold"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-0.5">Penanggung Jawab Tindakan (RTP)</label>
                        <input
                          type="text"
                          value={rtpPenanggungJawab}
                          onChange={(e) => setRtpPenanggungJawab(e.target.value)}
                          className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] text-slate-500 dark:text-slate-400 mb-0.5">Target Waktu Penyelesaian</label>
                        <input
                          type="text"
                          value={rtpTargetWaktu}
                          onChange={(e) => setRtpTargetWaktu(e.target.value)}
                          placeholder="e.g. Triwulan III 2026 atau Akhir Tahun 2026"
                          className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Actions for Edit Form */}
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      onClick={() => setEditingId(null)}
                      className="px-3.5 py-1.5 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded font-semibold text-xs cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      onClick={() => handleSave(risk.id)}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-xs flex items-center gap-1 cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>Simpan RTP</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
        {risks.length === 0 && (
          <div className="text-center py-12 text-slate-400 italic text-xs">
            Belum ada risiko strategis. Tambahkan risiko pada tab "Identifikasi Risiko" terlebih dahulu.
          </div>
        )}
      </div>

    </div>
  );
}
