import { useState, FormEvent } from "react";
import { RiskItem, RiskEvent } from "../types";
import { ListCollapse, Plus, Edit2, Trash2, Calendar, FileWarning, CheckCircle, Save, X } from "lucide-react";

interface PencatatanKejadianFormProps {
  risks: RiskItem[];
  events: RiskEvent[];
  onAddEvent: (event: RiskEvent) => void;
  onUpdateEvent: (id: string, updated: RiskEvent) => void;
  onDeleteEvent: (id: string) => void;
}

export function PencatatanKejadianForm(props: PencatatanKejadianFormProps) {
  const { risks, events, onAddEvent, onUpdateEvent, onDeleteEvent } = props;

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<RiskEvent | null>(null);

  // Form Field State
  const [formRiskId, setFormRiskId] = useState(risks[0]?.id || "");
  const [formTanggal, setFormTanggal] = useState("2026-07-12");
  const [formSebabNyata, setFormSebabNyata] = useState("");
  const [formDampakNyata, setFormDampakNyata] = useState("");
  const [formStatusRtp, setFormStatusRtp] = useState<"Belum Dilaksanakan" | "Sedang Dilaksanakan" | "Selesai Dilaksanakan">("Sedang Dilaksanakan");
  const [formKeterangan, setFormKeterangan] = useState("");

  const openAddModal = () => {
    setEditingEvent(null);
    setFormRiskId(risks[0]?.id || "");
    setFormTanggal("2026-07-12");
    setFormSebabNyata("");
    setFormDampakNyata("");
    setFormStatusRtp("Sedang Dilaksanakan");
    setFormKeterangan("");
    setIsModalOpen(true);
  };

  const openEditModal = (event: RiskEvent) => {
    setEditingEvent(event);
    setFormRiskId(event.riskId);
    setFormTanggal(event.tanggalKejadian);
    setFormSebabNyata(event.sebabNyata);
    setFormDampakNyata(event.dampakNyata);
    setFormStatusRtp(event.statusRtp);
    setFormKeterangan(event.keterangan);
    setIsModalOpen(true);
  };

  const handleSave = (e: FormEvent) => {
    e.preventDefault();
    if (!formRiskId || !formTanggal || !formSebabNyata || !formDampakNyata) {
      alert("Harap lengkapi semua field yang berbintang (*)");
      return;
    }

    if (editingEvent) {
      const updated: RiskEvent = {
        ...editingEvent,
        riskId: formRiskId,
        tanggalKejadian: formTanggal,
        sebabNyata: formSebabNyata,
        dampakNyata: formDampakNyata,
        statusRtp: formStatusRtp,
        keterangan: formKeterangan,
      };
      onUpdateEvent(editingEvent.id, updated);
    } else {
      const newEvent: RiskEvent = {
        id: `event-${Date.now()}`,
        riskId: formRiskId,
        tanggalKejadian: formTanggal,
        sebabNyata: formSebabNyata,
        dampakNyata: formDampakNyata,
        statusRtp: formStatusRtp,
        keterangan: formKeterangan,
      };
      onAddEvent(newEvent);
    }
    setIsModalOpen(false);
  };

  // Status badges mapping
  const getStatusBadge = (status: RiskEvent["statusRtp"]) => {
    if (status === "Belum Dilaksanakan") {
      return "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border-slate-200 dark:border-slate-700";
    }
    if (status === "Sedang Dilaksanakan") {
      return "bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400 border-amber-200 dark:border-amber-900/40";
    }
    return "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400 border-emerald-200 dark:border-emerald-900/40";
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
      
      {/* Header Form Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-4 mb-6 border-b border-slate-100 dark:border-slate-800 gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <ListCollapse className="w-5 h-5 text-amber-500" />
            Pencatatan Kejadian Risiko (Risk Event Log) & Evaluasi RTP
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Buku register pencatatan peristiwa risiko strategis yang benar-benar terjadi dalam tahun berjalan, untuk membandingkan mitigasi di kertas kerja dengan realisasi lapangan.
          </p>
        </div>
        <button
          onClick={openAddModal}
          disabled={risks.length === 0}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold shadow-sm transition-colors cursor-pointer self-stretch sm:self-auto justify-center ${
            risks.length === 0
              ? "bg-slate-200 text-slate-400 dark:bg-slate-800 cursor-not-allowed"
              : "bg-amber-500 hover:bg-amber-600 text-slate-900"
          }`}
        >
          <Plus className="w-4 h-4" />
          <span>Catat Kejadian Baru</span>
        </button>
      </div>

      {/* Main Table */}
      <div className="overflow-x-auto border border-slate-200 dark:border-slate-850 rounded-lg">
        <table className="w-full text-left border-collapse min-w-[950px]">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
              <th className="py-3 px-4 w-12 text-center">No</th>
              <th className="py-3 px-4 w-32">Kode Risiko</th>
              <th className="py-3 px-4 w-52">Identifikasi Risiko Awal</th>
              <th className="py-3 px-4 w-44">Tanggal Kejadian Nyata</th>
              <th className="py-3 px-4 w-60">Sebab Nyata Saat Terjadi</th>
              <th className="py-3 px-4 w-60">Dampak Kerugian Nyata</th>
              <th className="py-3 px-4 w-52">Rencana Mitigasi (RTP) Terkait</th>
              <th className="py-3 px-4 w-40 text-center">Status Mitigasi RTP</th>
              <th className="py-3 px-4 w-44">Keterangan Tambahan</th>
              <th className="py-3 px-4 w-24 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-800 dark:text-slate-200 align-top">
            {events.map((event, index) => {
              const matchedRisk = risks.find((r) => r.id === event.riskId);
              
              return (
                <tr key={`event-row-${event.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                  <td className="py-4 px-4 text-center font-bold text-slate-400">{index + 1}</td>
                  
                  {/* Risk Code */}
                  <td className="py-4 px-4 font-mono font-bold text-amber-600 dark:text-amber-400">
                    {matchedRisk ? matchedRisk.kodeRisiko : "KODE_HAPUS"}
                  </td>

                  {/* Initial Risk Description */}
                  <td className="py-4 px-4 leading-relaxed font-semibold">
                    {matchedRisk ? matchedRisk.uraianRisiko : <span className="text-rose-500 italic">Risiko induk telah dihapus</span>}
                  </td>

                  {/* Date occurred */}
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-1.5 font-bold text-slate-700 dark:text-slate-300">
                      <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{event.tanggalKejadian}</span>
                    </div>
                  </td>

                  {/* Real causes */}
                  <td className="py-4 px-4 leading-relaxed text-slate-600 dark:text-slate-400">
                    {event.sebabNyata}
                  </td>

                  {/* Real damages */}
                  <td className="py-4 px-4 leading-relaxed font-medium text-slate-900 dark:text-slate-200 bg-rose-500/5 rounded p-2 border border-rose-500/10">
                    <div className="flex gap-1.5 items-start">
                      <FileWarning className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                      <span>{event.dampakNyata}</span>
                    </div>
                  </td>

                  {/* Target RTP */}
                  <td className="py-4 px-4 text-slate-600 dark:text-slate-400 leading-relaxed">
                    {matchedRisk?.rtpRencanaTindakan ? (
                      <div className="italic text-slate-700 dark:text-slate-300 font-semibold bg-slate-100/50 dark:bg-slate-800/30 p-2 rounded">
                        {matchedRisk.rtpRencanaTindakan}
                      </div>
                    ) : (
                      <span className="text-slate-400 italic">Belum ditentukan program RTP</span>
                    )}
                  </td>

                  {/* Status */}
                  <td className="py-4 px-4 text-center">
                    <span className={`inline-block px-2.5 py-1 text-[10px] font-black rounded border ${getStatusBadge(event.statusRtp)}`}>
                      {event.statusRtp}
                    </span>
                  </td>

                  {/* Notes */}
                  <td className="py-4 px-4 text-slate-600 dark:text-slate-400 leading-relaxed">
                    {event.keterangan || "-"}
                  </td>

                  {/* Actions */}
                  <td className="py-4 px-4 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => openEditModal(event)}
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded transition-colors cursor-pointer"
                        title="Edit log kejadian"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm("Yakin ingin menghapus log kejadian ini?")) {
                            onDeleteEvent(event.id);
                          }
                        }}
                        className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 rounded transition-colors cursor-pointer"
                        title="Hapus log"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>

                </tr>
              );
            })}
            {events.length === 0 && (
              <tr>
                <td colSpan={10} className="py-12 text-center text-slate-400 italic">
                  Belum ada laporan kejadian risiko yang nyata dicatat untuk tahun berjalan.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add / Edit Event Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 w-full max-w-xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col">
            
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
                {editingEvent ? "Edit Laporan Kejadian Risiko" : "Registrasi Kejadian Risiko Nyata"}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-500 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
              
              {/* Linked Risk */}
              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Pilih Risiko Induk *</label>
                <select
                  value={formRiskId}
                  onChange={(e) => setFormRiskId(e.target.value)}
                  className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none"
                >
                  {risks.map((r) => (
                    <option key={`modal-evt-risk-${r.id}`} value={r.id}>
                      [{r.kodeRisiko}] {r.uraianRisiko.substring(0, 50)}...
                    </option>
                  ))}
                </select>
              </div>

              {/* Date */}
              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Tanggal Terjadinya Peristiwa *</label>
                <input
                  type="date"
                  value={formTanggal}
                  onChange={(e) => setFormTanggal(e.target.value)}
                  className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none"
                />
              </div>

              {/* Real Cause */}
              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Penyebab Sebenarnya (Sebab Nyata) *</label>
                <textarea
                  value={formSebabNyata}
                  onChange={(e) => setFormSebabNyata(e.target.value)}
                  rows={2}
                  placeholder="Uraikan faktor pemicu yang sebenarnya terjadi di lapangan..."
                  className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none"
                />
              </div>

              {/* Real Impact */}
              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Dampak Kerugian / Akibat Nyata *</label>
                <textarea
                  value={formDampakNyata}
                  onChange={(e) => setFormDampakNyata(e.target.value)}
                  rows={2}
                  placeholder="Sebutkan kerugian finansial, keterlambatan operasional, atau cidera reputasi yang ditimbulkan..."
                  className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none"
                />
              </div>

              {/* Status of RTP */}
              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Status Penyelenggaraan RTP Terkait</label>
                <select
                  value={formStatusRtp}
                  onChange={(e) => setFormStatusRtp(e.target.value as any)}
                  className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none"
                >
                  <option value="Belum Dilaksanakan">Belum Dilaksanakan</option>
                  <option value="Sedang Dilaksanakan">Sedang Dilaksanakan</option>
                  <option value="Selesai Dilaksanakan">Selesai / Selesai Efektif</option>
                </select>
              </div>

              {/* Comment */}
              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Keterangan / Evaluasi Lanjutan</label>
                <textarea
                  value={formKeterangan}
                  onChange={(e) => setFormKeterangan(e.target.value)}
                  rows={2}
                  placeholder="Keterangan tambahan atau catatan penanganan darurat..."
                  className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none"
                />
              </div>

              {/* Footer Actions */}
              <div className="border-t border-slate-150 dark:border-slate-800 pt-4 flex justify-end gap-3 bg-slate-50 dark:bg-slate-850 -mx-6 -mb-6 px-6 py-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-900 rounded-lg font-bold shadow-sm transition-colors cursor-pointer"
                >
                  {editingEvent ? "Simpan Perubahan" : "Catat Kejadian"}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
