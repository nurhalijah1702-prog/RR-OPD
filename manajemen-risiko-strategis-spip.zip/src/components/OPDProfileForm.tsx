import { useState } from "react";
import { OPDProfile, SasaranStrategis, IKUSasaran, ProgramStrategis, IKUProgram } from "../types";
import { Plus, Trash, Save, Edit2, Check, FileText } from "lucide-react";

interface OPDProfileFormProps {
  profile: OPDProfile;
  onChangeProfile: (updated: OPDProfile) => void;
}

export function OPDProfileForm(props: OPDProfileFormProps) {
  const { profile, onChangeProfile } = props;
  const [isEditing, setIsEditing] = useState(false);
  const [localProfile, setLocalProfile] = useState<OPDProfile>(profile);

  // Sync state if profile changes from parent
  const handleEditToggle = () => {
    if (isEditing) {
      onChangeProfile(localProfile);
    } else {
      setLocalProfile(profile);
    }
    setIsEditing(!isEditing);
  };

  const handleFieldChange = (field: keyof OPDProfile, value: any) => {
    setLocalProfile((prev) => ({ ...prev, [field]: value }));
  };

  // Strategic Objectives Handlers
  const handleAddSasaran = () => {
    const nextId = localProfile.sasaranStrategis.length > 0
      ? Math.max(...localProfile.sasaranStrategis.map((s) => s.id)) + 1
      : 1;
    const updated = [
      ...localProfile.sasaranStrategis,
      { id: nextId, text: `Sasaran Strategis Baru #${nextId}` },
    ];
    handleFieldChange("sasaranStrategis", updated);
  };

  const handleRemoveSasaran = (id: number) => {
    const updated = localProfile.sasaranStrategis.filter((s) => s.id !== id);
    handleFieldChange("sasaranStrategis", updated);
  };

  const handleUpdateSasaran = (id: number, text: string) => {
    const updated = localProfile.sasaranStrategis.map((s) =>
      s.id === id ? { ...s, text } : s
    );
    handleFieldChange("sasaranStrategis", updated);
  };

  // IKU Sasaran Handlers
  const handleAddIKUSasaran = () => {
    const nextId = localProfile.ikuSasaran.length > 0
      ? Math.max(...localProfile.ikuSasaran.map((i) => i.id)) + 1
      : 1;
    const updated = [
      ...localProfile.ikuSasaran,
      { id: nextId, text: `IKU Sasaran Baru #${nextId}`, target2026: "0.0" },
    ];
    handleFieldChange("ikuSasaran", updated);
  };

  const handleRemoveIKUSasaran = (id: number) => {
    const updated = localProfile.ikuSasaran.filter((i) => i.id !== id);
    handleFieldChange("ikuSasaran", updated);
  };

  const handleUpdateIKUSasaran = (id: number, field: keyof IKUSasaran, value: string) => {
    const updated = localProfile.ikuSasaran.map((i) =>
      i.id === id ? { ...i, [field]: value } : i
    );
    handleFieldChange("ikuSasaran", updated);
  };

  // Program Strategis Handlers
  const handleAddProgram = () => {
    const nextId = localProfile.programStrategis.length > 0
      ? Math.max(...localProfile.programStrategis.map((p) => p.id)) + 1
      : 1;
    const updated = [
      ...localProfile.programStrategis,
      { id: nextId, text: `Program Strategis Baru #${nextId}` },
    ];
    handleFieldChange("programStrategis", updated);
  };

  const handleRemoveProgram = (id: number) => {
    const updated = localProfile.programStrategis.filter((p) => p.id !== id);
    handleFieldChange("programStrategis", updated);
  };

  const handleUpdateProgram = (id: number, text: string) => {
    const updated = localProfile.programStrategis.map((p) =>
      p.id === id ? { ...p, text } : p
    );
    handleFieldChange("programStrategis", updated);
  };

  // IKU Program Handlers
  const handleAddIKUProgram = () => {
    const nextId = localProfile.ikuProgram.length > 0
      ? Math.max(...localProfile.ikuProgram.map((i) => i.id)) + 1
      : 1;
    const updated = [
      ...localProfile.ikuProgram,
      { id: nextId, text: `IKU Program Baru #${nextId}`, target2026: "0%" },
    ];
    handleFieldChange("ikuProgram", updated);
  };

  const handleRemoveIKUProgram = (id: number) => {
    const updated = localProfile.ikuProgram.filter((i) => i.id !== id);
    handleFieldChange("ikuProgram", updated);
  };

  const handleUpdateIKUProgram = (id: number, field: keyof IKUProgram, value: string) => {
    const updated = localProfile.ikuProgram.map((i) =>
      i.id === id ? { ...i, [field]: value } : i
    );
    handleFieldChange("ikuProgram", updated);
  };

  // Save the profile when editing finishes
  const handleSaveAll = () => {
    onChangeProfile(localProfile);
    setIsEditing(false);
  };

  // Determine which profile data to render
  const currentProfile = isEditing ? localProfile : profile;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-xs border border-slate-100 dark:border-slate-800 p-8">
      
      {/* Header Form Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-5 mb-6 border-b border-slate-100 dark:border-slate-800 gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <FileText className="w-4 h-4 text-slate-800 dark:text-slate-200" />
            Lampiran 5 (Form 2.b) - Penetapan Konteks Risiko Strategis OPD
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-light">
            Formulir dasar penentuan visi, misi, sasaran strategis, serta indikator kinerja utama (IKU) Organisasi Perangkat Daerah.
          </p>
        </div>
        <div className="flex gap-2">
          {isEditing ? (
            <button
              onClick={handleSaveAll}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-slate-200 text-white dark:text-slate-950 rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Simpan Perubahan</span>
            </button>
          ) : (
            <button
              onClick={handleEditToggle}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-slate-200 text-white dark:text-slate-950 rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span>Edit Formulir</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: General OPD Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 mb-6 bg-slate-50/60 dark:bg-slate-900/60 p-6 rounded-2xl border border-slate-100 dark:border-slate-800/80">
        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Nama Pemda</label>
          {isEditing ? (
            <input
              type="text"
              value={currentProfile.namaPemda}
              onChange={(e) => handleFieldChange("namaPemda", e.target.value)}
              className="w-full text-sm bg-white dark:bg-slate-850 text-slate-800 dark:text-slate-100 px-3 py-2 border border-slate-200 dark:border-slate-750 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-white"
            />
          ) : (
            <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">{currentProfile.namaPemda}</div>
          )}
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Tahun Penilaian</label>
          {isEditing ? (
            <input
              type="text"
              value={currentProfile.tahunPenilaian}
              onChange={(e) => handleFieldChange("tahunPenilaian", e.target.value)}
              className="w-full text-sm bg-white dark:bg-slate-850 text-slate-800 dark:text-slate-100 px-3 py-2 border border-slate-200 dark:border-slate-750 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-white"
            />
          ) : (
            <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">{currentProfile.tahunPenilaian}</div>
          )}
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Periode Renstra</label>
          {isEditing ? (
            <input
              type="text"
              value={currentProfile.periodeRenstra}
              onChange={(e) => handleFieldChange("periodeRenstra", e.target.value)}
              className="w-full text-sm bg-white dark:bg-slate-850 text-slate-800 dark:text-slate-100 px-3 py-2 border border-slate-200 dark:border-slate-750 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-white"
            />
          ) : (
            <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">{currentProfile.periodeRenstra}</div>
          )}
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Urusan Pemerintahan</label>
          {isEditing ? (
            <input
              type="text"
              value={currentProfile.urusanPemerintahan}
              onChange={(e) => handleFieldChange("urusanPemerintahan", e.target.value)}
              className="w-full text-sm bg-white dark:bg-slate-850 text-slate-800 dark:text-slate-100 px-3 py-2 border border-slate-200 dark:border-slate-750 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-white"
            />
          ) : (
            <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">{currentProfile.urusanPemerintahan}</div>
          )}
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">OPD yang Dinilai</label>
          {isEditing ? (
            <input
              type="text"
              value={currentProfile.opdYangDinilai}
              onChange={(e) => handleFieldChange("opdYangDinilai", e.target.value)}
              className="w-full text-sm bg-white dark:bg-slate-850 text-slate-800 dark:text-slate-100 px-3 py-2 border border-slate-200 dark:border-slate-750 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-white"
            />
          ) : (
            <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">{currentProfile.opdYangDinilai}</div>
          )}
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1">Sumber Data</label>
          {isEditing ? (
            <input
              type="text"
              value={currentProfile.sumberData}
              onChange={(e) => handleFieldChange("sumberData", e.target.value)}
              className="w-full text-sm bg-white dark:bg-slate-850 text-slate-800 dark:text-slate-100 px-3 py-2 border border-slate-200 dark:border-slate-750 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-white"
            />
          ) : (
            <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">{currentProfile.sumberData}</div>
          )}
        </div>
      </div>

      {/* Strategic Goal Section */}
      <div className="mb-6 bg-slate-50/60 dark:bg-slate-900/60 p-5 rounded-2xl border border-slate-100 dark:border-slate-800/80">
        <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1.5">Tujuan Strategis</label>
        {isEditing ? (
          <textarea
            value={currentProfile.tujuanStrategis}
            onChange={(e) => handleFieldChange("tujuanStrategis", e.target.value)}
            rows={2}
            className="w-full text-sm bg-white dark:bg-slate-850 text-slate-800 dark:text-slate-100 px-3 py-2 border border-slate-200 dark:border-slate-750 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-900 dark:focus:ring-white resize-none"
          />
        ) : (
          <div className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed font-semibold">
            {currentProfile.tujuanStrategis}
          </div>
        )}
      </div>

      {/* Strategic Objectives (Sasaran) & IKU Table */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
            Sasaran Strategis & IKU Sasaran OPD
          </h3>
          {isEditing && (
            <div className="flex gap-2">
              <button
                onClick={handleAddSasaran}
                className="flex items-center gap-1 bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-slate-200 text-white dark:text-slate-950 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>+ Sasaran</span>
              </button>
              <button
                onClick={handleAddIKUSasaran}
                className="flex items-center gap-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>+ IKU</span>
              </button>
            </div>
          )}
        </div>

        <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
                <th className="py-3 px-4 w-12 text-center">No</th>
                <th className="py-3 px-4">Sasaran Strategis</th>
                <th className="py-3 px-4">IKU Sasaran OPD</th>
                <th className="py-3 px-4 w-32 text-center">Target (2026)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm text-slate-800 dark:text-slate-200">
              {currentProfile.sasaranStrategis.map((sasaran, index) => {
                const associatedIKU = currentProfile.ikuSasaran[index];
                return (
                  <tr key={`sasaran-${sasaran.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                    <td className="py-3 px-4 font-bold text-center text-slate-400 dark:text-slate-500">{index + 1}</td>
                    <td className="py-3 px-4">
                      {isEditing ? (
                        <div className="flex gap-2 items-center">
                          <input
                            type="text"
                            value={sasaran.text}
                            onChange={(e) => handleUpdateSasaran(sasaran.id, e.target.value)}
                            className="w-full text-sm bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                          />
                          <button
                            onClick={() => handleRemoveSasaran(sasaran.id)}
                            className="p-1 hover:bg-rose-50 text-rose-500 hover:text-rose-600 rounded transition-colors"
                          >
                            <Trash className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span>{sasaran.text}</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {associatedIKU ? (
                        isEditing ? (
                          <div className="flex gap-2 items-center">
                            <input
                              type="text"
                              value={associatedIKU.text}
                              onChange={(e) => handleUpdateIKUSasaran(associatedIKU.id, "text", e.target.value)}
                              className="w-full text-sm bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                            />
                            <button
                              onClick={() => handleRemoveIKUSasaran(associatedIKU.id)}
                              className="p-1 hover:bg-rose-50 text-rose-500 hover:text-rose-600 rounded transition-colors"
                            >
                              <Trash className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <span>{associatedIKU.text}</span>
                        )
                      ) : (
                        <span className="text-slate-400 italic text-xs">Tidak ada IKU terkait</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {associatedIKU ? (
                        isEditing ? (
                          <input
                            type="text"
                            value={associatedIKU.target2026}
                            onChange={(e) => handleUpdateIKUSasaran(associatedIKU.id, "target2026", e.target.value)}
                            className="w-full text-center text-sm bg-white dark:bg-slate-800 px-1 py-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                          />
                        ) : (
                          <span className="font-semibold bg-slate-50 text-slate-800 dark:bg-slate-800 dark:text-slate-200 px-2.5 py-1 rounded text-xs border border-slate-100 dark:border-slate-700">
                            {associatedIKU.target2026}
                          </span>
                        )
                      ) : (
                        <span>-</span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {currentProfile.sasaranStrategis.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-400 dark:text-slate-500 italic">
                    Belum ada Sasaran Strategis yang dibuat. Klik Edit untuk menambah sasaran.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Program Strategis & IKU Program Table */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider">
            Program Strategis & IKU Program OPD
          </h3>
          {isEditing && (
            <div className="flex gap-2">
              <button
                onClick={handleAddProgram}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-slate-900 rounded text-xs font-semibold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Program</span>
              </button>
              <button
                onClick={handleAddIKUProgram}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-white rounded text-xs font-semibold transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ IKU Program</span>
              </button>
            </div>
          )}
        </div>

        <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
                <th className="py-3 px-4 w-12 text-center">No</th>
                <th className="py-3 px-4">Program Strategis</th>
                <th className="py-3 px-4">IKU Program</th>
                <th className="py-3 px-4 w-32 text-center">Target (2026)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm text-slate-800 dark:text-slate-200">
              {currentProfile.programStrategis.map((program, index) => {
                const associatedIKU = currentProfile.ikuProgram[index];
                return (
                  <tr key={`program-${program.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                    <td className="py-3 px-4 font-bold text-center text-slate-400 dark:text-slate-500">{index + 1}</td>
                    <td className="py-3 px-4">
                      {isEditing ? (
                        <div className="flex gap-2 items-center">
                          <input
                            type="text"
                            value={program.text}
                            onChange={(e) => handleUpdateProgram(program.id, e.target.value)}
                            className="w-full text-sm bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                          />
                          <button
                            onClick={() => handleRemoveProgram(program.id)}
                            className="p-1 hover:bg-rose-50 text-rose-500 hover:text-rose-600 rounded transition-colors"
                          >
                            <Trash className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <span>{program.text}</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      {associatedIKU ? (
                        isEditing ? (
                          <div className="flex gap-2 items-center">
                            <input
                              type="text"
                              value={associatedIKU.text}
                              onChange={(e) => handleUpdateIKUProgram(associatedIKU.id, "text", e.target.value)}
                              className="w-full text-sm bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                            />
                            <button
                              onClick={() => handleRemoveIKUProgram(associatedIKU.id)}
                              className="p-1 hover:bg-rose-50 text-rose-500 hover:text-rose-600 rounded transition-colors"
                            >
                              <Trash className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <span>{associatedIKU.text}</span>
                        )
                      ) : (
                        <span className="text-slate-400 italic text-xs">Tidak ada IKU terkait</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-center">
                      {associatedIKU ? (
                        isEditing ? (
                          <input
                            type="text"
                            value={associatedIKU.target2026}
                            onChange={(e) => handleUpdateIKUProgram(associatedIKU.id, "target2026", e.target.value)}
                            className="w-full text-center text-sm bg-white dark:bg-slate-800 px-1 py-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                          />
                        ) : (
                          <span className="font-semibold bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300 px-2.5 py-1 rounded text-xs">
                            {associatedIKU.target2026}
                          </span>
                        )
                      ) : (
                        <span>-</span>
                      )}
                    </td>
                  </tr>
                );
              })}
              {currentProfile.programStrategis.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-400 dark:text-slate-500 italic">
                    Belum ada Program Strategis yang dibuat. Klik Edit untuk menambah program.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Sign-Off Area (matching bottom right of sheet) */}
      <div className="border-t border-slate-100 dark:border-slate-800 pt-6 mt-6">
        <div className="flex flex-col md:flex-row md:justify-between items-start md:items-end gap-6">
          <div className="text-xs text-slate-400 dark:text-slate-500">
            * Lampiran ini merupakan landasan penetapan konteks risiko untuk diintegrasikan ke formulir identifikasi risiko strategis selanjutnya.
          </div>
          
          <div className="w-full md:w-80 bg-slate-50 dark:bg-slate-800/40 p-4 border border-slate-150 dark:border-slate-800 rounded-lg text-sm text-slate-800 dark:text-slate-200">
            {isEditing ? (
              <div className="space-y-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase">Tempat, Tanggal Penandatanganan</label>
                  <div className="flex gap-2 mt-0.5">
                    <input
                      type="text"
                      value={currentProfile.penandatanganTempat}
                      placeholder="Tempat"
                      onChange={(e) => handleFieldChange("penandatanganTempat", e.target.value)}
                      className="w-1/2 text-xs bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 rounded"
                    />
                    <input
                      type="text"
                      value={currentProfile.penandatanganTanggal}
                      placeholder="Tanggal"
                      onChange={(e) => handleFieldChange("penandatanganTanggal", e.target.value)}
                      className="w-1/2 text-xs bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 rounded"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase">Jabatan Penandatangan</label>
                  <input
                    type="text"
                    value={currentProfile.penandatanganJabatan}
                    onChange={(e) => handleFieldChange("penandatanganJabatan", e.target.value)}
                    className="w-full mt-0.5 text-xs bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 rounded"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase">Nama Penandatangan</label>
                  <input
                    type="text"
                    value={currentProfile.penandatanganNama}
                    onChange={(e) => handleFieldChange("penandatanganNama", e.target.value)}
                    className="w-full mt-0.5 text-xs bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 rounded font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase">Pangkat / Golongan</label>
                  <input
                    type="text"
                    value={currentProfile.penandatanganPangkat}
                    onChange={(e) => handleFieldChange("penandatanganPangkat", e.target.value)}
                    className="w-full mt-0.5 text-xs bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 rounded"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase">NIP</label>
                  <input
                    type="text"
                    value={currentProfile.penandatanganNIP}
                    onChange={(e) => handleFieldChange("penandatanganNIP", e.target.value)}
                    className="w-full mt-0.5 text-xs bg-white dark:bg-slate-800 px-2 py-1 border border-slate-200 rounded"
                  />
                </div>
              </div>
            ) : (
              <div className="text-center space-y-4">
                <div>
                  <span className="font-medium text-slate-700 dark:text-slate-300">{currentProfile.penandatanganTempat}</span>, {currentProfile.penandatanganTanggal}
                </div>
                <div className="font-bold text-xs uppercase tracking-wide text-slate-600 dark:text-slate-400">
                  {currentProfile.penandatanganJabatan}
                </div>
                <div className="pt-12">
                  <div className="font-bold text-base underline text-slate-900 dark:text-slate-100">{currentProfile.penandatanganNama}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{currentProfile.penandatanganPangkat}</div>
                  <div className="text-xs text-slate-500 dark:text-slate-400">NIP. {currentProfile.penandatanganNIP}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
}
