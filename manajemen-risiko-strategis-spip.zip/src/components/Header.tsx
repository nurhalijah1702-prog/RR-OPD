import { Shield, RefreshCw, Layers, AlertTriangle, CheckCircle } from "lucide-react";
import { RiskItem, OPDProfile } from "../types";
import { getAverageScore, getRiskLevel } from "../utils";

interface HeaderProps {
  profile: OPDProfile;
  risks: RiskItem[];
  onReset: () => void;
}

export function Header(props: HeaderProps) {
  const { profile, risks, onReset } = props;

  // Compute stats
  const totalRisks = risks.length;
  
  const highOrVeryHighRisks = risks.filter((r) => {
    const avgImpact = getAverageScore(r.skorDampak);
    const avgLike = getAverageScore(r.skorKemungkinan);
    const score = avgImpact * avgLike;
    return score >= 12;
  }).length;

  const totalScoreSum = risks.reduce((acc, r) => {
    const avgImpact = getAverageScore(r.skorDampak);
    const avgLike = getAverageScore(r.skorKemungkinan);
    return acc + (avgImpact * avgLike);
  }, 0);
  
  const averageRiskIndex = totalRisks > 0 ? (totalScoreSum / totalRisks).toFixed(2) : "0.00";

  return (
    <header className="bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100 border-b border-slate-100 dark:border-slate-900 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Brand/Logo Section */}
          <div className="flex items-center gap-4">
            <div className="p-2.5 bg-slate-900 text-white dark:bg-white dark:text-slate-900 rounded-xl shadow-xs shrink-0">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 dark:text-slate-500">
                Sistem Informasi Manajemen Risiko Strategis (SPIP)
              </div>
              <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
                {profile.opdYangDinilai}
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-light">
                {profile.namaPemda} • Tahun Penilaian {profile.tahunPenilaian}
              </p>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800/80 rounded-xl px-4 py-2 flex items-center gap-3 shadow-xs">
              <Layers className="w-4 h-4 text-slate-600 dark:text-slate-400" />
              <div>
                <div className="text-[9px] text-slate-400 dark:text-slate-500 font-semibold uppercase tracking-wider">Total Risiko</div>
                <div className="text-xs font-bold text-slate-800 dark:text-slate-200">{totalRisks} Item</div>
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800/80 rounded-xl px-4 py-2 flex items-center gap-3 shadow-xs">
              <AlertTriangle className="w-4 h-4 text-slate-600 dark:text-slate-400" />
              <div>
                <div className="text-[9px] text-slate-400 dark:text-slate-500 font-semibold uppercase tracking-wider">Risiko Tinggi/Sangat Tinggi</div>
                <div className="text-xs font-bold text-rose-600 dark:text-rose-400">{highOrVeryHighRisks} Item</div>
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800/80 rounded-xl px-4 py-2 flex items-center gap-3 shadow-xs">
              <CheckCircle className="w-4 h-4 text-slate-600 dark:text-slate-400" />
              <div>
                <div className="text-[9px] text-slate-400 dark:text-slate-500 font-semibold uppercase tracking-wider">Rata-rata Indeks</div>
                <div className="text-xs font-bold text-slate-800 dark:text-slate-200">{averageRiskIndex}</div>
              </div>
            </div>

            <button
              onClick={onReset}
              className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 active:bg-slate-950 dark:bg-slate-100 dark:hover:bg-slate-200 text-white dark:text-slate-950 text-xs font-semibold rounded-xl transition-all shadow-sm cursor-pointer self-stretch md:self-auto justify-center border border-transparent"
              title="Reset ke Data Standar Renstra"
            >
              <RefreshCw className="w-3.5 h-3.5 animate-duration-1000" />
              <span>Reset Data</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
}
