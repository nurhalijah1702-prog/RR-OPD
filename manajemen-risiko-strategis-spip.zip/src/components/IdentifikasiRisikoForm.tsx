import { useState, FormEvent } from "react";
import { RiskItem, OPDProfile } from "../types";
import { Search, Plus, Edit2, Trash2, ShieldAlert, Filter, HelpCircle, X, Check } from "lucide-react";

interface IdentifikasiRisikoFormProps {
  profile: OPDProfile;
  risks: RiskItem[];
  onAddRisk: (risk: RiskItem) => void;
  onUpdateRisk: (id: string, updated: RiskItem) => void;
  onDeleteRisk: (id: string) => void;
}

export function IdentifikasiRisikoForm(props: IdentifikasiRisikoFormProps) {
  const { profile, risks, onAddRisk, onUpdateRisk, onDeleteRisk } = props;

  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSumber, setFilterSumber] = useState<string>("ALL");
  const [filterCUC, setFilterCUC] = useState<string>("ALL");
  const [selectedSasaran, setSelectedSasaran] = useState<number | "ALL">("ALL");

  // Modal control
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRisk, setEditingRisk] = useState<RiskItem | null>(null);

  // Form Fields State
  const [formSasaranId, setFormSasaranId] = useState<number>(profile.sasaranStrategis[0]?.id || 1);
  const [formIndikator, setFormIndikator] = useState("");
  const [formKode, setFormKode] = useState("RSO.26.1.1.01");
  const [formUraian, setFormUraian] = useState("");
  const [formPemilik, setFormPemilik] = useState("");
  const [formSebabUraian, setFormSebabUraian] = useState("");
  const [formSebabSumber, setFormSebabSumber] = useState<"Internal" | "Eksternal">("Internal");
  const [formCUC, setFormCUC] = useState<"C" | "UC">("C");
  const [formDampakUraian, setFormDampakUraian] = useState("");
  const [formDampakPihak, setFormDampakPihak] = useState("");

  // Populate form for Edit
  const openEditModal = (risk: RiskItem) => {
    setEditingRisk(risk);
    setFormSasaranId(risk.sasaranId);
    setFormIndikator(risk.indikatorKinerja);
    setFormKode(risk.kodeRisiko);
    setFormUraian(risk.uraianRisiko);
    setFormPemilik(risk.pemilikRisiko);
    setFormSebabUraian(risk.penyebabUraian);
    setFormSebabSumber(risk.penyebabSumber);
    setFormCUC(risk.controllable);
    setFormDampakUraian(risk.dampakUraian);
    setFormDampakPihak(risk.dampakPihakTerkena);
    setIsModalOpen(true);
  };

  // Open empty form for Add
  const openAddModal = () => {
    setEditingRisk(null);
    // Generate an automatic code suggestion based on current count
    const nextNum = risks.length + 1;
    const paddedNum = String(nextNum).padStart(2, "0");
    
    setFormSasaranId(profile.sasaranStrategis[0]?.id || 1);
    setFormIndikator("");
    setFormKode(`RSO.26.1.1.${paddedNum}`);
    setFormUraian("");
    setFormPemilik("");
    setFormSebabUraian("");
    setFormSebabSumber("Internal");
    setFormCUC("C");
    setFormDampakUraian("");
    setFormDampakPihak("");
    setIsModalOpen(true);
  };

  const handleSave = (e: FormEvent) => {
    e.preventDefault();
    if (!formKode || !formUraian || !formPemilik) {
      alert("Harap lengkapi field Kode, Uraian, dan Pemilik Risiko!");
      return;
    }

    if (editingRisk) {
      // Edit existing
      const updated: RiskItem = {
        ...editingRisk,
        sasaranId: formSasaranId,
        indikatorKinerja: formIndikator,
        kodeRisiko: formKode,
        uraianRisiko: formUraian,
        pemilikRisiko: formPemilik,
        penyebabUraian: formSebabUraian,
        penyebabSumber: formSebabSumber,
        controllable: formCUC,
        dampakUraian: formDampakUraian,
        dampakPihakTerkena: formDampakPihak,
      };
      onUpdateRisk(editingRisk.id, updated);
    } else {
      // Add new
      const newRisk: RiskItem = {
        id: `risk-${Date.now()}`,
        sasaranId: formSasaranId,
        indikatorKinerja: formIndikator,
        kodeRisiko: formKode,
        uraianRisiko: formUraian,
        pemilikRisiko: formPemilik,
        penyebabUraian: formSebabUraian,
        penyebabSumber: formSebabSumber,
        controllable: formCUC,
        dampakUraian: formDampakUraian,
        dampakPihakTerkena: formDampakPihak,
        // Default scoring and control empty structures
        skorDampak: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
        skorKemungkinan: { A: 0, B: 0, C: 0, D: 0, E: 0, F: 0 },
        rtpUraianAda: "",
        rtpAlasanTidakEfektif: "",
        rtpDibutuhkan: "",
        rtpCelah: "",
        rtpRencanaTindakan: "",
        rtpPenanggungJawab: formPemilik,
        rtpTargetWaktu: "Triwulan I 2026",
        komunikasiMedia: "",
        komunikasiPenyedia: "",
        komunikasiPenerima: "",
        komunikasiRencanaWaktu: "",
        komunikasiRealisasi: "",
        komunikasiKeterangan: "",
        pantauMetode: "",
        pantauPJ: "",
        pantauRencanaWaktu: "",
        pantauRealisasi: "",
        pantauKeterangan: ""
      };
      onAddRisk(newRisk);
    }
    setIsModalOpen(false);
  };

  // Filter Risks
  const filteredRisks = risks.filter((r) => {
    const matchesSearch =
      r.kodeRisiko.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.uraianRisiko.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.pemilikRisiko.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.penyebabUraian.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.dampakUraian.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSumber = filterSumber === "ALL" || r.penyebabSumber === filterSumber;
    const matchesCUC = filterCUC === "ALL" || r.controllable === filterCUC;
    const matchesSasaran = selectedSasaran === "ALL" || r.sasaranId === Number(selectedSasaran);

    return matchesSearch && matchesSumber && matchesCUC && matchesSasaran;
  });

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
      
      {/* Title & Top Action */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-4 mb-6 border-b border-slate-100 dark:border-slate-800 gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-500" />
            Identifikasi Risiko Strategis OPD
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Proses pencatatan peristiwa risiko, penyebab, dampak, dan kemampuan OPD dalam mengendalikannya (Controllable / Uncontrollable).
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-slate-900 rounded-lg text-xs font-bold shadow-sm transition-colors cursor-pointer self-stretch sm:self-auto justify-center"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Risiko Baru</span>
        </button>
      </div>

      {/* Filters Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 mb-6 bg-slate-50 dark:bg-slate-800/30 p-4 rounded-lg border border-slate-150 dark:border-slate-800/60">
        
        {/* Search */}
        <div className="relative">
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Cari Kata Kunci</label>
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Kode, Uraian, Pemilik..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white dark:bg-slate-850 text-xs text-slate-800 dark:text-slate-200 pl-9 pr-3 py-2 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500"
            />
          </div>
        </div>

        {/* Sasaran Filter */}
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Filter Sasaran</label>
          <select
            value={selectedSasaran}
            onChange={(e) => setSelectedSasaran(e.target.value === "ALL" ? "ALL" : Number(e.target.value))}
            className="w-full bg-white dark:bg-slate-850 text-xs text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="ALL">Semua Sasaran ({profile.sasaranStrategis.length})</option>
            {profile.sasaranStrategis.map((s) => (
              <option key={`filter-sasaran-${s.id}`} value={s.id}>
                Sasaran {s.id}: {s.text.substring(0, 45)}...
              </option>
            ))}
          </select>
        </div>

        {/* Sumber Filter */}
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Sumber Penyebab</label>
          <select
            value={filterSumber}
            onChange={(e) => setFilterSumber(e.target.value)}
            className="w-full bg-white dark:bg-slate-850 text-xs text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="ALL">Semua Sumber</option>
            <option value="Internal">Internal</option>
            <option value="Eksternal">Eksternal</option>
          </select>
        </div>

        {/* C/UC Filter */}
        <div>
          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Kategori C/UC</label>
          <select
            value={filterCUC}
            onChange={(e) => setFilterCUC(e.target.value)}
            className="w-full bg-white dark:bg-slate-850 text-xs text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-none focus:ring-1 focus:ring-amber-500"
          >
            <option value="ALL">Semua Pengendalian</option>
            <option value="C">C (Controllable)</option>
            <option value="UC">UC (Uncontrollable)</option>
          </select>
        </div>

      </div>

      {/* Main Table */}
      <div className="overflow-x-auto border border-slate-200 dark:border-slate-850 rounded-lg">
        <table className="w-full text-left border-collapse min-w-[1100px]">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
              <th className="py-3 px-3 w-12 text-center">No</th>
              <th className="py-3 px-3 w-48">Tujuan/Sasaran Strategis</th>
              <th className="py-3 px-3 w-40">Indikator Kinerja</th>
              <th className="py-3 px-3 w-32">Kode Risiko</th>
              <th className="py-3 px-3 w-56">Uraian Peristiwa Risiko</th>
              <th className="py-3 px-3 w-40">Pemilik Risiko</th>
              <th className="py-3 px-3 w-56">Penyebab (Sebab)</th>
              <th className="py-3 px-3 w-20 text-center">Sumber</th>
              <th className="py-3 px-3 w-16 text-center">C/UC</th>
              <th className="py-3 px-3 w-56">Dampak Akibat</th>
              <th className="py-3 px-3 w-32 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-700 dark:text-slate-300">
            {filteredRisks.map((risk, idx) => {
              const sasaranText = profile.sasaranStrategis.find((s) => s.id === risk.sasaranId)?.text || "Sasaran tidak ditemukan";
              return (
                <tr key={`risk-row-${risk.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10 align-top">
                  <td className="py-4 px-3 text-center font-bold text-slate-400">{idx + 1}</td>
                  
                  {/* Goal/Objective */}
                  <td className="py-4 px-3 leading-relaxed">
                    <span className="font-semibold text-slate-900 dark:text-slate-200">Sasaran {risk.sasaranId}:</span>{" "}
                    <span className="text-slate-500 dark:text-slate-400">{sasaranText}</span>
                  </td>
                  
                  {/* KPI */}
                  <td className="py-4 px-3 leading-relaxed">{risk.indikatorKinerja}</td>
                  
                  {/* Risk Code */}
                  <td className="py-4 px-3 font-mono font-bold text-amber-600 dark:text-amber-400">{risk.kodeRisiko}</td>
                  
                  {/* Risk Description */}
                  <td className="py-4 px-3 leading-relaxed font-medium text-slate-900 dark:text-slate-200">{risk.uraianRisiko}</td>
                  
                  {/* Risk Owner */}
                  <td className="py-4 px-3 font-semibold text-slate-800 dark:text-slate-300">{risk.pemilikRisiko}</td>
                  
                  {/* Cause description */}
                  <td className="py-4 px-3 leading-relaxed">{risk.penyebabUraian}</td>
                  
                  {/* Cause Source */}
                  <td className="py-4 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      risk.penyebabSumber === "Internal"
                        ? "bg-sky-50 text-sky-700 dark:bg-sky-950/30 dark:text-sky-400"
                        : "bg-purple-50 text-purple-700 dark:bg-purple-950/30 dark:text-purple-400"
                    }`}>
                      {risk.penyebabSumber}
                    </span>
                  </td>
                  
                  {/* Controllable */}
                  <td className="py-4 px-3 text-center font-bold">
                    <span className={`px-2 py-0.5 rounded text-[10px] ${
                      risk.controllable === "C"
                        ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/30 dark:text-emerald-400"
                        : "bg-rose-50 text-rose-700 dark:bg-rose-950/30 dark:text-rose-400"
                    }`}>
                      {risk.controllable}
                    </span>
                  </td>
                  
                  {/* Impact */}
                  <td className="py-4 px-3 leading-relaxed">
                    <span className="text-slate-800 dark:text-slate-300">{risk.dampakUraian}</span>
                    <div className="text-[10px] text-slate-400 mt-1">Pihak Terkena: <span className="font-semibold text-slate-600 dark:text-slate-300">{risk.dampakPihakTerkena}</span></div>
                  </td>
                  
                  {/* Actions */}
                  <td className="py-4 px-3 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <button
                        onClick={() => openEditModal(risk)}
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 rounded transition-colors cursor-pointer"
                        title="Edit detail risiko"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Yakin ingin menghapus risiko ${risk.kodeRisiko}?`)) {
                            onDeleteRisk(risk.id);
                          }
                        }}
                        className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 dark:bg-rose-950/20 dark:hover:bg-rose-950/40 rounded transition-colors cursor-pointer"
                        title="Hapus risiko"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>

                </tr>
              );
            })}
            {filteredRisks.length === 0 && (
              <tr>
                <td colSpan={11} className="py-12 text-center text-slate-400 dark:text-slate-500 italic">
                  Tidak ditemukan data risiko strategis yang sesuai filter.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Unified Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 w-full max-w-2xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col">
            
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-800/50">
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">
                {editingRisk ? `Edit Risiko Strategis: ${formKode}` : "Tambah Risiko Strategis Baru"}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-500 dark:hover:text-slate-300 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body / Form */}
            <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
              
              {/* Sasaran Link */}
              <div>
                <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Sasaran Strategis Hubungan</label>
                <select
                  value={formSasaranId}
                  onChange={(e) => setFormSasaranId(Number(e.target.value))}
                  className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
                >
                  {profile.sasaranStrategis.map((s) => (
                    <option key={`modal-sasaran-${s.id}`} value={s.id}>
                      Sasaran {s.id}: {s.text}
                    </option>
                  ))}
                </select>
              </div>

              {/* KPI & Code */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Indikator Kinerja</label>
                  <input
                    type="text"
                    value={formIndikator}
                    onChange={(e) => setFormIndikator(e.target.value)}
                    placeholder="e.g. Peningkatan Nilai Investasi"
                    className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Kode Risiko</label>
                  <input
                    type="text"
                    value={formKode}
                    onChange={(e) => setFormKode(e.target.value)}
                    placeholder="e.g. RSO.26.1.1.01"
                    className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500 font-mono font-bold"
                  />
                </div>
              </div>

              {/* Risk Description & Owner */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Uraian Peristiwa Risiko</label>
                  <textarea
                    value={formUraian}
                    onChange={(e) => setFormUraian(e.target.value)}
                    rows={3}
                    placeholder="Deskripsikan peristiwa ketidakpastian / kegagalan pencapaian tujuan..."
                    className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-600 dark:text-slate-400 uppercase mb-1">Pemilik Risiko (Unit PJ)</label>
                  <input
                    type="text"
                    value={formPemilik}
                    onChange={(e) => setFormPemilik(e.target.value)}
                    placeholder="e.g. Kepala Dinas PTSP"
                    className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500 font-semibold"
                  />
                </div>
              </div>

              {/* Cause (Sebab) */}
              <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                <h4 className="font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide mb-2 text-[10px]">Identifikasi Penyebab (Sebab)</h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 mb-1">Uraian Penyebab</label>
                    <textarea
                      value={formSebabUraian}
                      onChange={(e) => setFormSebabUraian(e.target.value)}
                      rows={2}
                      placeholder="Uraikan penyebab munculnya risiko (Man, Money, Method, Machine, Material)..."
                      className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-slate-500 dark:text-slate-400 mb-1">Sumber Penyebab</label>
                      <select
                        value={formSebabSumber}
                        onChange={(e) => setFormSebabSumber(e.target.value as "Internal" | "Eksternal")}
                        className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none"
                      >
                        <option value="Internal">Internal (Dalam Kendali OPD/Pemda)</option>
                        <option value="Eksternal">Eksternal (Luar Kendali)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-500 dark:text-slate-400 mb-1">Kategori C / UC</label>
                      <select
                        value={formCUC}
                        onChange={(e) => setFormCUC(e.target.value as "C" | "UC")}
                        className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none"
                      >
                        <option value="C">C (Controllable - Mampu Dikendalikan)</option>
                        <option value="UC">UC (Uncontrollable - Sulit Dikendalikan)</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Impact (Dampak) */}
              <div className="border-t border-slate-100 dark:border-slate-800 pt-4">
                <h4 className="font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide mb-2 text-[10px]">Identifikasi Dampak Akibat</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 mb-1">Uraian Akibat</label>
                    <textarea
                      value={formDampakUraian}
                      onChange={(e) => setFormDampakUraian(e.target.value)}
                      rows={2}
                      placeholder="Kerugian finansial, reputasi, kinerja, hukum jika risiko terjadi..."
                      className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 dark:text-slate-400 mb-1">Pihak / Unit yang Terkena</label>
                    <textarea
                      value={formDampakPihak}
                      onChange={(e) => setFormDampakPihak(e.target.value)}
                      rows={2}
                      placeholder="Siapa saja pihak yang menderita/terkena dampak akibat..."
                      className="w-full bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 px-3 py-2 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* Footer Actions */}
              <div className="border-t border-slate-150 dark:border-slate-800 pt-4 flex justify-end gap-3 bg-slate-50 dark:bg-slate-850 -mx-6 -mb-6 px-6 py-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-slate-700 dark:text-slate-300 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-600 active:bg-amber-700 text-slate-900 rounded-lg font-bold shadow-sm transition-colors cursor-pointer"
                >
                  {editingRisk ? "Simpan Perubahan" : "Tambah Risiko"}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
}
