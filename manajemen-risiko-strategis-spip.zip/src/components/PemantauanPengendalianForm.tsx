import { useState } from "react";
import { RiskItem } from "../types";
import { Eye, Edit2, Save, CheckCircle, AlertCircle } from "lucide-react";

interface PemantauanPengendalianFormProps {
  risks: RiskItem[];
  onUpdatePemantauan: (id: string, updatedPemantauan: Partial<RiskItem>) => void;
}

export function PemantauanPengendalianForm(props: PemantauanPengendalianFormProps) {
  const { risks, onUpdatePemantauan } = props;

  const [editingId, setEditingId] = useState<string | null>(null);

  // Local state for editing fields
  const [pantauMetode, setPantauMetode] = useState("");
  const [pantauPJ, setPantauPJ] = useState("");
  const [pantauRencanaWaktu, setPantauRencanaWaktu] = useState("");
  const [pantauRealisasi, setPantauRealisasi] = useState("");
  const [pantauKeterangan, setPantauKeterangan] = useState("");

  const startEditing = (risk: RiskItem) => {
    setEditingId(risk.id);
    setPantauMetode(risk.pantauMetode || "");
    setPantauPJ(risk.pantauPJ || "Inspektur Pembantu Wilayah I");
    setPantauRencanaWaktu(risk.pantauRencanaWaktu || "Setiap Akhir Bulan");
    setPantauRealisasi(risk.pantauRealisasi || "");
    setPantauKeterangan(risk.pantauKeterangan || "");
  };

  const handleSave = (riskId: string) => {
    onUpdatePemantauan(riskId, {
      pantauMetode,
      pantauPJ,
      pantauRencanaWaktu,
      pantauRealisasi,
      pantauKeterangan,
    });
    setEditingId(null);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
      
      {/* Title */}
      <div className="pb-4 mb-6 border-b border-slate-100 dark:border-slate-800">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <Eye className="w-5 h-5 text-amber-500" />
          Rencana & Realisasi Pemantauan Kegiatan Pengendalian (Form 9)
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Formulir penentuan mekanisme/metode monitoring, penanggung jawab verifikasi pelaksanaan RTP, rencana timeline monitoring, serta evaluasi tindak lanjutnya.
        </p>
      </div>

      {/* Table of Monitoring */}
      <div className="overflow-x-auto border border-slate-200 dark:border-slate-850 rounded-lg">
        <table className="w-full text-left border-collapse min-w-[950px]">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
              <th className="py-3 px-4 w-12 text-center">No</th>
              <th className="py-3 px-4 w-32">Kode Risiko</th>
              <th className="py-3 px-4 w-52">Program Pengendalian (RTP)</th>
              <th className="py-3 px-4 w-44">Bentuk / Metode Pemantauan</th>
              <th className="py-3 px-4 w-40">Penanggung Jawab Pemantauan</th>
              <th className="py-3 px-4 w-36">Rencana Waktu Pemantauan</th>
              <th className="py-3 px-4 w-36">Realisasi Pelaksanaan</th>
              <th className="py-3 px-4 w-44">Keterangan Hasil Evaluasi</th>
              <th className="py-3 px-4 w-24 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-800 dark:text-slate-200 align-top">
            {risks.map((risk, index) => {
              const isEditing = editingId === risk.id;
              const hasRTP = !!risk.rtpRencanaTindakan;

              return (
                <tr key={`pantau-row-${risk.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                  <td className="py-4 px-4 text-center font-bold text-slate-400">{index + 1}</td>
                  <td className="py-4 px-4 font-mono font-bold text-amber-600 dark:text-amber-400">{risk.kodeRisiko}</td>
                  
                  {/* Linked RTP Activity */}
                  <td className="py-4 px-4">
                    {hasRTP ? (
                      <div className="font-bold text-slate-900 dark:text-slate-200 leading-relaxed bg-slate-50 dark:bg-slate-800/30 p-2 rounded border border-slate-100 dark:border-slate-800/60">
                        {risk.rtpRencanaTindakan}
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-rose-500 bg-rose-50 dark:bg-rose-950/20 p-2 rounded border border-rose-100 dark:border-rose-900/40 font-medium">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>Rencana Tindakan (RTP) belum diisi pada menu RTP!</span>
                      </div>
                    )}
                  </td>

                  {/* Method */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <textarea
                        value={pantauMetode}
                        onChange={(e) => setPantauMetode(e.target.value)}
                        rows={2}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1.5 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                        placeholder="e.g. Audit berkala, verifikasi dokumen, monitoring bulanan"
                      />
                    ) : (
                      <span className="font-medium text-slate-700 dark:text-slate-300">{risk.pantauMetode || "-"}</span>
                    )}
                  </td>

                  {/* PJ Pemantauan */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <input
                        type="text"
                        value={pantauPJ}
                        onChange={(e) => setPantauPJ(e.target.value)}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                      />
                    ) : (
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{risk.pantauPJ || "-"}</span>
                    )}
                  </td>

                  {/* Target Timeline */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <input
                        type="text"
                        value={pantauRencanaWaktu}
                        onChange={(e) => setPantauRencanaWaktu(e.target.value)}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                      />
                    ) : (
                      <span className="font-bold text-slate-700 dark:text-slate-300">{risk.pantauRencanaWaktu || "-"}</span>
                    )}
                  </td>

                  {/* Realisation */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <input
                        type="text"
                        value={pantauRealisasi}
                        onChange={(e) => setPantauRealisasi(e.target.value)}
                        placeholder="e.g. Terlaksana bulanan lancar"
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                      />
                    ) : (
                      risk.pantauRealisasi ? (
                        <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold">
                          <CheckCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{risk.pantauRealisasi}</span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Belum terlaksana</span>
                      )
                    )}
                  </td>

                  {/* Notes / Evaluation */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <textarea
                        value={pantauKeterangan}
                        onChange={(e) => setPantauKeterangan(e.target.value)}
                        rows={2}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1.5 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                        placeholder="Hasil temuan, hambatan, saran perbaikan..."
                      />
                    ) : (
                      <span className="text-slate-600 dark:text-slate-400">{risk.pantauKeterangan || "-"}</span>
                    )}
                  </td>

                  {/* Edit action */}
                  <td className="py-3 px-3 text-center">
                    {isEditing ? (
                      <div className="flex flex-col gap-1.5 justify-center items-center">
                        <button
                          onClick={() => handleSave(risk.id)}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-[10px] cursor-pointer flex items-center gap-1 w-full justify-center"
                        >
                          <Save className="w-3 h-3" />
                          <span>Simpan</span>
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="px-2.5 py-1 border border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded text-[10px] cursor-pointer w-full text-center"
                        >
                          Batal
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => startEditing(risk)}
                        disabled={!hasRTP}
                        className={`p-1.5 rounded transition-colors cursor-pointer flex items-center justify-center gap-1 mx-auto ${
                          hasRTP
                            ? "bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300"
                            : "bg-slate-50 text-slate-300 dark:bg-slate-900 cursor-not-allowed opacity-40"
                        }`}
                        title={hasRTP ? "Edit rencana pemantauan" : "Harap isi RTP terlebih dahulu"}
                      >
                        <Edit2 className="w-3.5 h-3.5 text-amber-500" />
                        <span className="text-[10px] font-bold">Edit</span>
                      </button>
                    )}
                  </td>

                </tr>
              );
            })}
            {risks.length === 0 && (
              <tr>
                <td colSpan={9} className="py-12 text-center text-slate-400 italic">
                  Belum ada risiko strategis. Tambahkan risiko pada tab "Identifikasi Risiko" terlebih dahulu.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
}
