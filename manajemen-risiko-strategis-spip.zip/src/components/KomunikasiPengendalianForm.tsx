import { useState } from "react";
import { RiskItem } from "../types";
import { MessageSquare, Edit2, Save, Send, CheckCircle2, AlertCircle } from "lucide-react";

interface KomunikasiPengendalianFormProps {
  risks: RiskItem[];
  onUpdateKomunikasi: (id: string, updatedKomunikasi: Partial<RiskItem>) => void;
}

export function KomunikasiPengendalianForm(props: KomunikasiPengendalianFormProps) {
  const { risks, onUpdateKomunikasi } = props;

  const [editingId, setEditingId] = useState<string | null>(null);

  // Local state for editing fields
  const [komunikasiMedia, setKomunikasiMedia] = useState("");
  const [komunikasiPenyedia, setKomunikasiPenyedia] = useState("");
  const [komunikasiPenerima, setKomunikasiPenerima] = useState("");
  const [komunikasiRencanaWaktu, setKomunikasiRencanaWaktu] = useState("");
  const [komunikasiRealisasi, setKomunikasiRealisasi] = useState("");
  const [komunikasiKeterangan, setKomunikasiKeterangan] = useState("");

  const startEditing = (risk: RiskItem) => {
    setEditingId(risk.id);
    setKomunikasiMedia(risk.komunikasiMedia || "");
    setKomunikasiPenyedia(risk.komunikasiPenyedia || risk.pemilikRisiko);
    setKomunikasiPenerima(risk.komunikasiPenerima || "");
    setKomunikasiRencanaWaktu(risk.komunikasiRencanaWaktu || risk.rtpTargetWaktu || "");
    setKomunikasiRealisasi(risk.komunikasiRealisasi || "");
    setKomunikasiKeterangan(risk.komunikasiKeterangan || "");
  };

  const handleSave = (riskId: string) => {
    onUpdateKomunikasi(riskId, {
      komunikasiMedia,
      komunikasiPenyedia,
      komunikasiPenerima,
      komunikasiRencanaWaktu,
      komunikasiRealisasi,
      komunikasiKeterangan,
    });
    setEditingId(null);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
      
      {/* Title */}
      <div className="pb-4 mb-6 border-b border-slate-100 dark:border-slate-800">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-amber-500" />
          Rencana & Realisasi Pengkomunikasian Kegiatan Pengendalian (Form 8)
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Formulir penentuan media, penyedia informasi, kelompok sasaran penerima, serta pencatatan realisasi waktu pengkomunikasian program mitigasi risiko strategis.
        </p>
      </div>

      {/* Table of Communication */}
      <div className="overflow-x-auto border border-slate-200 dark:border-slate-850 rounded-lg">
        <table className="w-full text-left border-collapse min-w-[950px]">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
              <th className="py-3 px-4 w-12 text-center">No</th>
              <th className="py-3 px-4 w-32">Kode Risiko</th>
              <th className="py-3 px-4 w-52">Program Pengendalian (RTP)</th>
              <th className="py-3 px-4 w-44">Media / Bentuk Sarana</th>
              <th className="py-3 px-4 w-40">Penyedia Informasi</th>
              <th className="py-3 px-4 w-40">Penerima Informasi</th>
              <th className="py-3 px-4 w-36">Rencana Waktu</th>
              <th className="py-3 px-4 w-36">Realisasi Pelaksanaan</th>
              <th className="py-3 px-4 w-44">Keterangan Tambahan</th>
              <th className="py-3 px-4 w-24 text-center">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-800 dark:text-slate-200 align-top">
            {risks.map((risk, index) => {
              const isEditing = editingId === risk.id;
              const hasRTP = !!risk.rtpRencanaTindakan;

              return (
                <tr key={`komunikasi-row-${risk.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                  <td className="py-4 px-4 text-center font-bold text-slate-400">{index + 1}</td>
                  <td className="py-4 px-4 font-mono font-bold text-amber-600 dark:text-amber-400">{risk.kodeRisiko}</td>
                  
                  {/* Linked RTP Activity */}
                  <td className="py-4 px-4">
                    {hasRTP ? (
                      <div className="font-bold text-slate-900 dark:text-slate-200 leading-relaxed bg-slate-50 dark:bg-slate-800/30 p-2 rounded border border-slate-100 dark:border-slate-800/60">
                        {risk.rtpRencanaTindakan}
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-rose-500 bg-rose-50 dark:bg-rose-950/20 p-2 rounded border border-rose-100 dark:border-rose-900/40 font-medium">
                        <AlertCircle className="w-4 h-4 shrink-0" />
                        <span>Rencana Tindakan (RTP) belum diisi pada menu RTP!</span>
                      </div>
                    )}
                  </td>

                  {/* Media */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <textarea
                        value={komunikasiMedia}
                        onChange={(e) => setKomunikasiMedia(e.target.value)}
                        rows={2}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1.5 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                        placeholder="e.g. Sosialisasi, SE, Rapat koordinasi"
                      />
                    ) : (
                      <span className="font-medium text-slate-700 dark:text-slate-300">{risk.komunikasiMedia || "-"}</span>
                    )}
                  </td>

                  {/* Provider */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <input
                        type="text"
                        value={komunikasiPenyedia}
                        onChange={(e) => setKomunikasiPenyedia(e.target.value)}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                      />
                    ) : (
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{risk.komunikasiPenyedia || "-"}</span>
                    )}
                  </td>

                  {/* Receiver */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <textarea
                        value={komunikasiPenerima}
                        onChange={(e) => setKomunikasiPenerima(e.target.value)}
                        rows={2}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1.5 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                        placeholder="e.g. Bendahara, Pelaku Usaha"
                      />
                    ) : (
                      <span className="text-slate-700 dark:text-slate-300">{risk.komunikasiPenerima || "-"}</span>
                    )}
                  </td>

                  {/* Target Date */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <input
                        type="text"
                        value={komunikasiRencanaWaktu}
                        onChange={(e) => setKomunikasiRencanaWaktu(e.target.value)}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                      />
                    ) : (
                      <span className="font-bold text-slate-700 dark:text-slate-300">{risk.komunikasiRencanaWaktu || "-"}</span>
                    )}
                  </td>

                  {/* Actual Date */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <input
                        type="text"
                        value={komunikasiRealisasi}
                        onChange={(e) => setKomunikasiRealisasi(e.target.value)}
                        placeholder="e.g. Selesai 12 Juli 2026"
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                      />
                    ) : (
                      risk.komunikasiRealisasi ? (
                        <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold">
                          <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                          <span>{risk.komunikasiRealisasi}</span>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Belum terlaksana</span>
                      )
                    )}
                  </td>

                  {/* Notes / Keterangan */}
                  <td className="py-3 px-3">
                    {isEditing ? (
                      <textarea
                        value={komunikasiKeterangan}
                        onChange={(e) => setKomunikasiKeterangan(e.target.value)}
                        rows={2}
                        className="w-full text-xs bg-white dark:bg-slate-800 p-1.5 border border-slate-200 dark:border-slate-700 rounded focus:outline-none"
                        placeholder="Keterangan tindak lanjut..."
                      />
                    ) : (
                      <span className="text-slate-600 dark:text-slate-400">{risk.komunikasiKeterangan || "-"}</span>
                    )}
                  </td>

                  {/* Edit action */}
                  <td className="py-3 px-3 text-center">
                    {isEditing ? (
                      <div className="flex flex-col gap-1.5 justify-center items-center">
                        <button
                          onClick={() => handleSave(risk.id)}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold text-[10px] cursor-pointer flex items-center gap-1 w-full justify-center"
                        >
                          <Save className="w-3 h-3" />
                          <span>Simpan</span>
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="px-2.5 py-1 border border-slate-300 text-slate-700 dark:border-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded text-[10px] cursor-pointer w-full text-center"
                        >
                          Batal
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => startEditing(risk)}
                        disabled={!hasRTP}
                        className={`p-1.5 rounded transition-colors cursor-pointer flex items-center justify-center gap-1 mx-auto ${
                          hasRTP
                            ? "bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-300"
                            : "bg-slate-50 text-slate-300 dark:bg-slate-900 cursor-not-allowed opacity-40"
                        }`}
                        title={hasRTP ? "Edit rencana komunikasi" : "Harap isi RTP terlebih dahulu"}
                      >
                        <Edit2 className="w-3.5 h-3.5 text-amber-500" />
                        <span className="text-[10px] font-bold">Edit</span>
                      </button>
                    )}
                  </td>

                </tr>
              );
            })}
            {risks.length === 0 && (
              <tr>
                <td colSpan={10} className="py-12 text-center text-slate-400 italic">
                  Belum ada risiko strategis. Tambahkan risiko pada tab "Identifikasi Risiko" terlebih dahulu.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
}
