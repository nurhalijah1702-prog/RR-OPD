import { RiskItem } from "../types";
import { getAverageScore, getRiskLevel } from "../utils";
import { Award, AlertOctagon, ArrowDownNarrowWide, CheckSquare } from "lucide-react";

interface PrioritasRisikoFormProps {
  risks: RiskItem[];
}

export function PrioritasRisikoForm(props: PrioritasRisikoFormProps) {
  const { risks } = props;

  // Compute and sort risks based on risk score (Impact * Likelihood) descending
  const sortedRisks = [...risks]
    .map((r) => {
      const avgImpact = getAverageScore(r.skorDampak);
      const avgLike = getAverageScore(r.skorKemungkinan);
      const score = avgImpact * avgLike;
      return {
        ...r,
        avgImpact,
        avgLike,
        score,
      };
    })
    .sort((a, b) => b.score - a.score);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
      
      {/* Title */}
      <div className="pb-4 mb-6 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <ArrowDownNarrowWide className="w-5 h-5 text-amber-500" />
            Daftar Risiko Prioritas Utama (Sorted)
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Daftar urutan peristiwa risiko strategis dari yang paling kritis (skor tertinggi) untuk diprioritaskan penanganannya oleh pimpinan.
          </p>
        </div>
        <div className="bg-amber-500/10 border border-amber-500/20 text-amber-800 dark:text-amber-400 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 select-none">
          <Award className="w-4 h-4" />
          <span>Prioritas Diurutkan</span>
        </div>
      </div>

      {/* Grid Summary List */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {sortedRisks.slice(0, 3).map((r, i) => {
          const rLevel = getRiskLevel(r.score);
          const iconColors = [
            "text-rose-600 bg-rose-50 border-rose-200 dark:bg-rose-950/20 dark:border-rose-900",
            "text-orange-600 bg-orange-50 border-orange-200 dark:bg-orange-950/20 dark:border-orange-900",
            "text-amber-600 bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900",
          ];
          return (
            <div
              key={`top-3-prioritas-${r.id}`}
              className={`p-4 border rounded-xl flex flex-col justify-between ${
                i === 0 
                  ? "ring-2 ring-rose-500/30 border-rose-200 dark:border-rose-900 bg-rose-50/10" 
                  : "bg-slate-50/50 dark:bg-slate-800/10 border-slate-200 dark:border-slate-800"
              }`}
            >
              <div>
                <div className="flex justify-between items-start mb-2">
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded border uppercase tracking-wider ${iconColors[i] || ""}`}>
                    Peringkat #{i + 1}
                  </span>
                  <span className={`text-xs font-black text-slate-850 dark:text-slate-100`}>
                    Skor: <span className="text-sm font-black underline">{r.score.toFixed(2)}</span>
                  </span>
                </div>
                <h4 className="font-bold text-xs text-slate-800 dark:text-slate-100 line-clamp-2 mt-2 leading-relaxed">
                  {r.uraianRisiko}
                </h4>
                <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-1">
                  PJ: <span className="font-semibold text-slate-700 dark:text-slate-300">{r.pemilikRisiko}</span>
                </p>
              </div>
              <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-[10px]">
                <span className="text-slate-400 font-mono font-bold">{r.kodeRisiko}</span>
                <span className={`px-2 py-0.5 rounded-full font-bold ${rLevel.bgClass} ${rLevel.textClass}`}>
                  {rLevel.label}
                </span>
              </div>
            </div>
          );
        })}
        {sortedRisks.length === 0 && (
          <div className="col-span-3 p-4 text-center border border-dashed border-slate-300 dark:border-slate-800 rounded-xl text-xs text-slate-400 italic">
            Belum ada data risiko strategis yang dimasukkan.
          </div>
        )}
      </div>

      {/* Kertas Kerja Table */}
      <div className="overflow-x-auto border border-slate-200 dark:border-slate-850 rounded-lg">
        <table className="w-full text-left border-collapse min-w-[950px]">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
              <th className="py-3 px-4 w-16 text-center">Prioritas</th>
              <th className="py-3 px-4 w-32">Kode Risiko</th>
              <th className="py-3 px-4 w-52">Uraian Risiko Prioritas</th>
              <th className="py-3 px-4 w-24 text-center">Skala Risiko</th>
              <th className="py-3 px-4 w-40">Pemilik Risiko (PJ)</th>
              <th className="py-3 px-4 w-60">Penyebab Utama</th>
              <th className="py-3 px-4 w-60">Dampak Utama</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-800 dark:text-slate-200 align-top">
            {sortedRisks.map((risk, index) => {
              const rLevel = getRiskLevel(risk.score);
              return (
                <tr key={`priority-table-${risk.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                  <td className="py-4 px-4 text-center">
                    <span className="inline-flex items-center justify-center w-6 h-6 bg-slate-900 text-amber-500 font-black rounded-md text-xs shadow-sm">
                      {index + 1}
                    </span>
                  </td>
                  <td className="py-4 px-4 font-mono font-bold text-amber-600 dark:text-amber-400">{risk.kodeRisiko}</td>
                  <td className="py-4 px-4">
                    <div className="font-bold text-slate-900 dark:text-slate-200 leading-relaxed">
                      {risk.uraianRisiko}
                    </div>
                  </td>
                  <td className="py-4 px-4 text-center font-black">
                    <div className="text-sm">{risk.score.toFixed(2)}</div>
                    <span className={`inline-block px-1.5 py-0.5 text-[9px] font-bold rounded-full mt-1 border ${rLevel.bgClass} ${rLevel.textClass} ${rLevel.borderClass}`}>
                      {rLevel.label}
                    </span>
                  </td>
                  <td className="py-4 px-4 font-semibold text-slate-700 dark:text-slate-300">{risk.pemilikRisiko}</td>
                  <td className="py-4 px-4 leading-relaxed text-slate-600 dark:text-slate-400">
                    {risk.penyebabUraian}
                    <div className="mt-1 text-[10px] font-bold text-slate-400">Sumber: <span className="text-slate-500 dark:text-slate-300 font-normal">{risk.penyebabSumber} ({risk.controllable})</span></div>
                  </td>
                  <td className="py-4 px-4 leading-relaxed text-slate-600 dark:text-slate-400">
                    {risk.dampakUraian}
                    <div className="mt-1 text-[10px] font-bold text-slate-400">Pihak Terkena: <span className="text-slate-500 dark:text-slate-300 font-normal">{risk.dampakPihakTerkena}</span></div>
                  </td>
                </tr>
              );
            })}
            {sortedRisks.length === 0 && (
              <tr>
                <td colSpan={7} className="py-12 text-center text-slate-400 dark:text-slate-500 italic">
                  Belum ada risiko strategis yang dimasukkan. Silakan tambahkan risiko di menu "Identifikasi Risiko".
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
}
