import { useState } from "react";
import { RiskItem } from "../types";
import { getAverageScore, getRiskLevel, RiskLevelInfo } from "../utils";
import { Compass, Flame, Info, Table } from "lucide-react";

interface HasilAnalisisFormProps {
  risks: RiskItem[];
}

export function HasilAnalisisForm(props: HasilAnalisisFormProps) {
  const { risks } = props;

  // Selected cell coordinates for heatmap filtering (null means show all)
  const [selectedCell, setSelectedCell] = useState<{ impact: number; likelihood: number } | null>(null);

  // Helper to round average to nearest integer for grid positioning
  const getNearestCoord = (risk: RiskItem) => {
    const avgImpact = getAverageScore(risk.skorDampak);
    const avgLike = getAverageScore(risk.skorKemungkinan);
    return {
      impact: Math.max(1, Math.min(5, Math.round(avgImpact))),
      likelihood: Math.max(1, Math.min(5, Math.round(avgLike))),
      exactImpact: avgImpact,
      exactLike: avgLike,
      score: avgImpact * avgLike
    };
  };

  // Pre-calculate risk coordinates
  const risksWithCoords = risks.map((r) => {
    const coords = getNearestCoord(r);
    return {
      ...r,
      coords,
    };
  });

  // Count how many risks are in a specific coordinate
  const getRisksInCell = (likelihood: number, impact: number) => {
    return risksWithCoords.filter(
      (rw) => rw.coords.likelihood === likelihood && rw.coords.impact === impact
    );
  };

  // Generate coordinate cell style based on score value
  const getCellBg = (likelihood: number, impact: number) => {
    const score = likelihood * impact;
    if (score < 6) return "bg-emerald-500/20 text-emerald-800 border-emerald-300 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-800/80 hover:bg-emerald-500/30";
    if (score < 12) return "bg-amber-500/20 text-amber-800 border-amber-300 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-800/80 hover:bg-amber-500/30";
    if (score < 16) return "bg-orange-500/20 text-orange-800 border-orange-300 dark:bg-orange-950/40 dark:text-orange-400 dark:border-orange-800/80 hover:bg-orange-500/30";
    return "bg-rose-500/20 text-rose-800 border-rose-300 dark:bg-rose-950/40 dark:text-rose-400 dark:border-rose-800/80 hover:bg-rose-500/30";
  };

  const getCellLabelColor = (likelihood: number, impact: number) => {
    const score = likelihood * impact;
    if (score < 6) return "text-emerald-600 dark:text-emerald-400";
    if (score < 12) return "text-amber-600 dark:text-amber-400";
    if (score < 16) return "text-orange-600 dark:text-orange-400";
    return "text-rose-600 dark:text-rose-400";
  };

  // Rows are likelihood (5 down to 1), cols are impact (1 up to 5)
  const likelihoodLevels = [5, 4, 3, 2, 1];
  const impactLevels = [1, 2, 3, 4, 5];

  // Filter list of risks shown below based on cell clicked
  const displayedRisks = selectedCell
    ? risksWithCoords.filter(
        (rw) => rw.coords.likelihood === selectedCell.likelihood && rw.coords.impact === selectedCell.impact
      )
    : risksWithCoords;

  return (
    <div className="space-y-6">
      
      {/* Heatmap Section Card */}
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
        <div className="flex justify-between items-start pb-4 mb-6 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Compass className="w-5 h-5 text-amber-500" />
              Peta Sebaran Risiko (Risk Heatmap 5x5)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Visualisasi sebaran risiko berdasarkan koordinat rata-rata skala dampak (X) dan kemungkinan (Y). Klik pada kotak peta untuk memfilter daftar risiko terkait.
            </p>
          </div>
          {selectedCell && (
            <button
              onClick={() => setSelectedCell(null)}
              className="text-xs font-semibold px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 rounded cursor-pointer"
            >
              Tampilkan Semua
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          {/* Interactive Heatmap Column (lg:col-span-7) */}
          <div className="lg:col-span-7 flex flex-col items-center">
            <div className="w-full max-w-[500px]">
              
              {/* Top Y-Axis Label (Kemungkinan) */}
              <div className="text-center font-bold text-xs uppercase tracking-widest text-slate-400 dark:text-slate-500 mb-2">
                &larr; Skala Kemungkinan / Probabilitas (Y) &rarr;
              </div>

              <div className="flex">
                
                {/* Left Y-Axis labels */}
                <div className="flex flex-col justify-between py-6 pr-2 text-right text-xs font-bold text-slate-400 select-none w-6">
                  <span>5</span>
                  <span>4</span>
                  <span>3</span>
                  <span>2</span>
                  <span>1</span>
                </div>

                {/* 5x5 Heatmap Matrix */}
                <div className="grid grid-cols-5 gap-1.5 flex-1 aspect-square border-2 border-slate-300 dark:border-slate-800 p-2 rounded-xl bg-slate-50 dark:bg-slate-950/20">
                  {likelihoodLevels.map((l) =>
                    impactLevels.map((i) => {
                      const risksInCell = getRisksInCell(l, i);
                      const isSelected = selectedCell?.likelihood === l && selectedCell?.impact === i;
                      const hasRisks = risksInCell.length > 0;
                      
                      return (
                        <div
                          key={`cell-${l}-${i}`}
                          onClick={() => {
                            if (isSelected) {
                              setSelectedCell(null);
                            } else {
                              setSelectedCell({ likelihood: l, impact: i });
                            }
                          }}
                          className={`relative aspect-square border rounded-lg cursor-pointer transition-all flex flex-col items-center justify-center p-1 select-none ${getCellBg(
                            l,
                            i
                          )} ${
                            isSelected
                              ? "ring-4 ring-amber-500 scale-102 z-10 shadow-lg border-amber-500"
                              : "border-slate-200/40"
                          }`}
                        >
                          {/* Top-left score math coordinate indicator (small) */}
                          <div className="absolute top-1 left-1.5 text-[8px] font-bold opacity-60">
                            {i}x{l}
                          </div>

                          {/* Inner Score Label */}
                          <div className="text-xs font-extrabold mt-1">
                            {i * l}
                          </div>

                          {/* Risk Badge Count */}
                          {hasRisks && (
                            <div className="mt-1 bg-slate-950 text-white dark:bg-white dark:text-slate-950 font-black text-[10px] w-5 h-5 rounded-full flex items-center justify-center shadow-md animate-pulse">
                              {risksInCell.length}
                            </div>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>

              </div>

              {/* Bottom X-Axis Label (Dampak) */}
              <div className="flex pl-8 mt-2 justify-between text-xs font-bold text-slate-400 select-none px-4">
                <span>1</span>
                <span>2</span>
                <span>3</span>
                <span>4</span>
                <span>5</span>
              </div>
              <div className="text-center font-bold text-xs uppercase tracking-widest text-slate-400 dark:text-slate-500 mt-2">
                &larr; Skala Dampak / Konsekuensi (X) &rarr;
              </div>

            </div>
          </div>

          {/* Legend and Info Panel (lg:col-span-5) */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide">
              Keterangan Skala Risiko (Indeks)
            </h3>
            
            <div className="space-y-2 text-xs">
              
              <div className="flex items-center gap-3 p-2 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/60 rounded-lg">
                <div className="w-4 h-4 bg-emerald-500 rounded-sm"></div>
                <div className="flex-1">
                  <div className="font-bold text-emerald-800 dark:text-emerald-400">Skor 1 - 5: Kategori RENDAH</div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Penanganan rutin, pengawasan berkala oleh Kepala Seksi/Staf terkait.</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-2 bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/60 rounded-lg">
                <div className="w-4 h-4 bg-amber-500 rounded-sm"></div>
                <div className="flex-1">
                  <div className="font-bold text-amber-800 dark:text-amber-400">Skor 6 - 11: Kategori MODERAT</div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Memerlukan mitigasi formal dan pemantauan triwulan oleh Kepala Bidang.</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-2 bg-orange-50 dark:bg-orange-950/20 border border-orange-100 dark:border-orange-900/60 rounded-lg">
                <div className="w-4 h-4 bg-orange-500 rounded-sm"></div>
                <div className="flex-1">
                  <div className="font-bold text-orange-800 dark:text-orange-400">Skor 12 - 15: Kategori TINGGI</div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Memerlukan Rencana Tindak Pengendalian (RTP) segera dan pelaporan ke Kepala Dinas.</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-2 bg-rose-50 dark:bg-rose-950/20 border border-rose-100 dark:border-rose-900/60 rounded-lg">
                <div className="w-4 h-4 bg-rose-500 rounded-sm"></div>
                <div className="flex-1">
                  <div className="font-bold text-rose-800 dark:text-rose-400">Skor 16 - 25: Kategori SANGAT TINGGI</div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">Krisis! Eskalasi utama, tindakan perbaikan harian, diawasi langsung oleh Inspektur/Kepala Dinas.</p>
                </div>
              </div>

            </div>

            {selectedCell ? (
              <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-lg text-xs">
                <div className="font-bold text-slate-800 dark:text-amber-400">Penyaringan Aktif:</div>
                <p className="text-[10px] text-slate-600 dark:text-slate-300 mt-1">
                  Menampilkan risiko dengan nilai pembulatan Dampak <span className="font-bold">x{selectedCell.impact}</span> dan Kemungkinan <span className="font-bold">x{selectedCell.likelihood}</span>.
                </p>
              </div>
            ) : (
              <div className="p-3 bg-slate-50 dark:bg-slate-850/80 rounded-lg text-xs flex gap-2">
                <Info className="w-4 h-4 text-slate-400 shrink-0" />
                <p className="text-[10px] text-slate-500 dark:text-slate-400">
                  Koordinat X dan Y dicocokkan dengan pembulatan nilai rata-rata peserta diskusi terdekat agar rapi pada petak grid 5x5.
                </p>
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Calculated Result Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
        <div className="pb-4 mb-4 border-b border-slate-100 dark:border-slate-800">
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Table className="w-5 h-5 text-amber-500" />
            Tabel Analisis Nilai Risiko Strategis (Dampak x Kemungkinan)
          </h3>
        </div>

        <div className="overflow-x-auto border border-slate-200 dark:border-slate-850 rounded-lg">
          <table className="w-full text-left border-collapse min-w-[700px]">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
                <th className="py-3 px-4 w-12 text-center">No</th>
                <th className="py-3 px-4 w-32">Kode Risiko</th>
                <th className="py-3 px-4">Uraian Risiko Teridentifikasi</th>
                <th className="py-3 px-4 w-32 text-center">Rata-rata Dampak (X)</th>
                <th className="py-3 px-4 w-32 text-center">Rata-rata Kemungkinan (Y)</th>
                <th className="py-3 px-4 w-32 text-center">Skala Risiko (f=dxe)</th>
                <th className="py-3 px-4 w-40 text-center">Kategori Tingkat Risiko</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-800 dark:text-slate-250">
              {displayedRisks.map((rw, index) => {
                const avgImpact = getAverageScore(rw.skorDampak);
                const avgLike = getAverageScore(rw.skorKemungkinan);
                const score = avgImpact * avgLike;
                const rLevel = getRiskLevel(score);

                return (
                  <tr key={`analisis-${rw.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                    <td className="py-4 px-4 text-center font-bold text-slate-400">{index + 1}</td>
                    <td className="py-4 px-4 font-mono font-bold text-amber-600 dark:text-amber-400">{rw.kodeRisiko}</td>
                    <td className="py-4 px-4 leading-relaxed">
                      <div className="font-semibold text-slate-900 dark:text-slate-200">{rw.uraianRisiko}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Pemilik: <span className="font-semibold">{rw.pemilikRisiko}</span></div>
                    </td>
                    <td className="py-4 px-4 text-center font-bold">{avgImpact.toFixed(2)}</td>
                    <td className="py-4 px-4 text-center font-bold">{avgLike.toFixed(2)}</td>
                    <td className="py-4 px-4 text-center font-black text-sm text-slate-900 dark:text-white">
                      {score.toFixed(2)}
                    </td>
                    <td className="py-4 px-4 text-center">
                      <span className={`inline-block px-3 py-1 text-[10px] font-extrabold rounded-full border ${rLevel.bgClass} ${rLevel.borderClass} ${rLevel.textClass}`}>
                        {rLevel.label}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {displayedRisks.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400 dark:text-slate-500 italic">
                    {selectedCell 
                      ? "Tidak ada risiko strategis pada koordinat petak ini."
                      : "Belum ada risiko strategis yang ditambahkan."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
