import { RiskItem, ParticipantScores } from "../types";
import { getAverageScore } from "../utils";
import { TrendingUp, Info } from "lucide-react";

interface SkalaKemungkinanFormProps {
  risks: RiskItem[];
  onUpdateScores: (id: string, updatedScores: ParticipantScores) => void;
}

export function SkalaKemungkinanForm(props: SkalaKemungkinanFormProps) {
  const { risks, onUpdateScores } = props;

  const handleScoreChange = (riskId: string, participant: keyof ParticipantScores, valStr: string) => {
    const value = valStr === "" ? 0 : parseInt(valStr);
    const risk = risks.find((r) => r.id === riskId);
    if (risk) {
      const updatedScores = {
        ...risk.skorKemungkinan,
        [participant]: value,
      };
      onUpdateScores(riskId, updatedScores);
    }
  };

  const handleSetAllParticipantScores = (riskId: string, value: number) => {
    const updatedScores = { A: value, B: value, C: value, D: value, E: value, F: value };
    onUpdateScores(riskId, updatedScores);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-200 dark:border-slate-800 p-6">
      
      {/* Title */}
      <div className="pb-4 mb-6 border-b border-slate-100 dark:border-slate-800">
        <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-amber-500" />
          Formulir Perhitungan Rata-rata Skala Kemungkinan
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Lakukan penilaian skala kemungkinan (skala 1 s.d 5) terjadinya peristiwa risiko berdasarkan hasil diskusi bersama peserta (A s.d F).
        </p>
      </div>

      {/* Guide Card */}
      <div className="mb-6 bg-slate-50 dark:bg-slate-800/40 p-4 border border-slate-200 dark:border-slate-800 rounded-lg flex gap-3 text-xs">
        <Info className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <div className="leading-relaxed text-slate-600 dark:text-slate-300">
          <span className="font-bold">Panduan Skala Kemungkinan (Likelihood) SPIP:</span>
          <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 mt-2 font-medium">
            <span className="text-emerald-600 dark:text-emerald-400">1 = Hampir Tidak Terjadi (Sangat Jarang)</span>
            <span className="text-sky-600 dark:text-sky-400">2 = Jarang Terjadi</span>
            <span className="text-amber-600 dark:text-amber-400">3 = Kadang-kadang Terjadi</span>
            <span className="text-orange-600 dark:text-orange-400">4 = Sering Terjadi</span>
            <span className="text-rose-600 dark:text-rose-400">5 = Hampir Pasti Terjadi (Sangat Sering)</span>
          </div>
        </div>
      </div>

      {/* Table of Likelihood Scoring */}
      <div className="overflow-x-auto border border-slate-200 dark:border-slate-850 rounded-lg">
        <table className="w-full text-left border-collapse min-w-[800px]">
          <thead>
            <tr className="bg-slate-50 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 text-xs font-bold border-b border-slate-200 dark:border-slate-800">
              <th className="py-3 px-4 w-12 text-center">No</th>
              <th className="py-3 px-4 w-32">Kode Risiko</th>
              <th className="py-3 px-4">Uraian Risiko</th>
              <th className="py-3 px-4 text-center col-span-6" style={{ width: "360px" }}>
                Skala Kemungkinan Menurut Peserta (FGD)
              </th>
              <th className="py-3 px-4 w-28 text-center">Skor Rata-rata</th>
            </tr>
            <tr className="bg-slate-100/50 dark:bg-slate-800/40 text-slate-500 dark:text-slate-400 text-[10px] font-bold border-b border-slate-200 dark:border-slate-800">
              <th></th>
              <th></th>
              <th></th>
              {["Peserta A", "Peserta B", "Peserta C", "Peserta D", "Peserta E", "Peserta F"].map((p, i) => (
                <th key={`header-p-${i}`} className="py-1.5 text-center w-12 border-r border-slate-200/50 dark:border-slate-800/50">
                  {p.replace("Peserta ", "")}
                </th>
              ))}
              <th></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm text-slate-800 dark:text-slate-200">
            {risks.map((risk, index) => {
              const avgScore = getAverageScore(risk.skorKemungkinan);
              return (
                <tr key={`like-scoring-${risk.id}`} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10">
                  <td className="py-4 px-4 font-bold text-slate-400 text-center">{index + 1}</td>
                  <td className="py-4 px-4 font-mono font-bold text-amber-600 dark:text-amber-400">{risk.kodeRisiko}</td>
                  <td className="py-4 px-4 leading-relaxed">
                    <div className="font-semibold">{risk.uraianRisiko}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Pemilik: <span className="font-medium text-slate-600 dark:text-slate-300">{risk.pemilikRisiko}</span></div>
                  </td>

                  {/* Individual Scores */}
                  {(["A", "B", "C", "D", "E", "F"] as (keyof ParticipantScores)[]).map((p) => {
                    const val = risk.skorKemungkinan[p];
                    return (
                      <td key={`cell-${risk.id}-${p}`} className="py-3 px-1 border-r border-slate-100 dark:border-slate-800 text-center">
                        <select
                          value={val || ""}
                          onChange={(e) => handleScoreChange(risk.id, p, e.target.value)}
                          className="mx-auto w-12 bg-white dark:bg-slate-850 text-xs font-bold text-slate-800 dark:text-slate-200 p-1 border border-slate-300 dark:border-slate-700 rounded focus:outline-none focus:ring-1 focus:ring-amber-500"
                        >
                          <option value="0">-</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                        </select>
                      </td>
                    );
                  })}

                  {/* Average Output */}
                  <td className="py-4 px-4 text-center">
                    <div className="flex flex-col items-center justify-center gap-1">
                      <span className="font-black text-slate-900 dark:text-white bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded text-xs">
                        {avgScore.toFixed(2)}
                      </span>
                      {/* Batch helpers */}
                      <div className="flex gap-1 justify-center">
                        {[1, 3, 5].map((sc) => (
                          <button
                            key={`batch-like-${sc}`}
                            onClick={() => handleSetAllParticipantScores(risk.id, sc)}
                            className="text-[9px] px-1 bg-slate-50 hover:bg-amber-100 border border-slate-200 dark:bg-slate-800/80 dark:border-slate-700 text-slate-500 rounded cursor-pointer transition-colors"
                            title={`Set semua peserta ke nilai ${sc}`}
                          >
                            all:{sc}
                          </button>
                        ))}
                      </div>
                    </div>
                  </td>

                </tr>
              );
            })}
            {risks.length === 0 && (
              <tr>
                <td colSpan={11} className="py-12 text-center text-slate-400 dark:text-slate-500 italic">
                  Belum ada risiko strategis yang ditambahkan. Silakan tambahkan risiko di menu "Identifikasi Risiko" terlebih dahulu.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

    </div>
  );
}
